<?php
	include_once("../tools/head.php");
	if(print_head('',true,true,true,array('use'),false)!='ok')
	{
		echo json_encode(array('login'=>false));
		exit();
	}
	$questionid		=$_GET[questionid];
	$ansid			=$_GET[ansid];
	$ojclassid		=json_decode(preg_replace('/(^\d\[\]\,)/i','',urldecode($_GET['ojclassid'])));
	@$conn2=connect_sql();
	$check='no';		
	global $questionlist;
	function get_next_time($data,$error)
	{
		if($error)
			$minute=0.5;
		else
		{
			if($data['times']>3)
				$minute=120;
			else if($data['times']>0)
				$minute=10;
			else if($data['times']>-2)//小于2次
				$minute=8;
			else if($data['times']>-4)//小于4次
				$minute=4;
			else if($data['times']>-6)//小于6次
				$minute=2;
		}
		return date('Y-m-d H:i:s',time()+$minute*60);
	}
	//检验正误
	if($ansid!='no')
	{
		$check=true;
		$ans=	$_GET[ans];
		$q='SELECT *
		FROM '.constant('ojdb').'questionlist
		WHERE '.constant('ojpro').'questionlist.ojquestionid=?
		LIMIT 1
		';
		$st = $conn2->prepare($q);
		$st->bindParam(1,$ansid);
		$st->execute();	
		foreach($st->fetchAll() as $questionlist);
		if($ans==$questionlist['ans'])
		{
			//添加错题本
			$st = $conn2->prepare("SELECT *FROM ".constant("ojdb")."error WHERE id=? AND ojquestionid=?");
			$st->bindParam(1,$_USER[id]);
			$st->bindParam(2,$ansid);
			$st->execute();		
			foreach($st->fetchAll() as $erroryuan);	
			if($st->rowCount()==0)
			{
				$st = $conn2->prepare("INSERT INTO ".constant("ojdb")."error (id,ojquestionid,times,maxtimes,nexttime,lasttime) VALUES (?,?,'0','0',?,?)");
				$st->bindParam(1,$_USER['id']);
				$st->bindParam(2,$ansid);
				$st->bindParam(3,get_next_time($erroryuan,false));
				$st->bindParam(4,get_time());
				$st->execute();					
			}
			else
			{
				$st = $conn2->prepare("UPDATE ".constant("ojdb")."error SET times=times+1,nexttime=?,lasttime=? WHERE id=? AND ojquestionid=?");
				$st->bindParam(1,get_next_time($erroryuan,false));
				$st->bindParam(2,get_time());
				$st->bindParam(3,$_USER[id]);
				$st->bindParam(4,$ansid);
				$st->execute();					
			}
			//记录提交
			$st = $conn2->prepare("INSERT INTO ".constant("ojdb")."logs (id,ojquestionid,time,logans,result) VALUES (?,?,?,?,'right')");
			$st->bindParam(1,$_USER['id']);
			$st->bindParam(2,$ansid);
			$st->bindParam(3,get_time());
			$st->bindParam(4,$ans);
			$st->execute();
			$check=true;
		}
		else
		{
			//添加错题本
			$st = $conn2->prepare("SELECT *FROM ".constant("ojdb")."error WHERE id=? AND ojquestionid=?");
			$st->bindParam(1,$_USER[id]);
			$st->bindParam(2,$ansid);
			$st->execute();		
			foreach($st->fetchAll() as $erroryuan);	
			if($st->rowCount()==0)
			{
				$st = $conn2->prepare("INSERT INTO ".constant("ojdb")."error (id,ojquestionid,times,maxtimes,nexttime,lasttime) VALUES (?,?,-1,-1,?,?)");
				$st->bindParam(1,$_USER['id']);
				$st->bindParam(2,$ansid);
				$st->bindParam(3,get_next_time($erroryuan,false));
				$st->bindParam(4,get_time());
				$st->execute();									
			}
			else
			{
				$st = $conn2->prepare("UPDATE ".constant("ojdb")."error SET nexttime=?,times=times-1,lasttime=?,maxtimes= (case when maxtimes > times then times else maxtimes end) WHERE id=? AND ojquestionid=?");
				$st->bindParam(1,get_next_time($erroryuan,false));
				$st->bindParam(2,get_time());
				$st->bindParam(3,$_USER['id']);
				$st->bindParam(4,$ansid);
				$st->execute();					
			}
			//记录提交
			$st = $conn2->prepare("INSERT INTO ".constant("ojdb")."logs (id,ojquestionid,time,logans,result) VALUES (?,?,?,?,'error')");
			$st->bindParam(1,$_USER['id']);
			$st->bindParam(2,$ansid);
			$st->bindParam(3,get_time());
			$st->bindParam(4,$ans);
			$st->execute();
			$check=false;	
			$questionid=$ansid;
		}
			
	}
	$_type='lasterror';
	if($questionid!='rand')//制定题目
	{
		$_type='point';	
		$q='SELECT * FROM '.constant('ojdb').'questionlist 
			where ojquestionid=? LIMIT 1
		';		
		$st = $conn2->prepare($q);
		$st->bindParam(1,$questionid);
		$st->execute();
		foreach($st->fetchAll() as $questionlist);
	}
	else//做错题
	{
		$_type='error';	
		$q='SELECT *
		FROM '.constant('ojdb').'link
		INNER JOIN '.constant('ojdb').'error  ON (
			'.constant('ojpro').'error.ojquestionid = '.constant('ojpro').'link.ojquestionid
			AND '.constant('ojpro').'error.id = ?
			AND '.constant('ojpro').'error.nexttime < ?
			AND '.constant('ojpro').'error.times < 0
			)
		INNER JOIN '.constant('ojdb').'questionlist  ON (
			'.constant('ojpro').'questionlist.ojquestionid = '.constant('ojpro').'link.ojquestionid
			)
		WHERE '.constant('ojpro').'link.ojclassid IN ('.implode(',',$ojclassid).')
		AND '.constant('ojpro').'link.ojquestionid!=?			
		ORDER BY '.constant('ojpro').'error.times ASC
		LIMIT 1
		';
		$st = $conn2->prepare($q);
		$st->bindParam(1,$_USER['id']);		
		$st->bindParam(2,get_time());
		$st->bindParam(3,$ansid);		
		$st->execute();
		foreach($st->fetchAll() as $questionlist);	
		if($st->rowCount()==0)//无错题，做没有的
		{
			$_type='notdo';	
			$q='SELECT *
			FROM '.constant('ojdb').'link
			INNER JOIN '.constant('ojdb').'questionlist  ON (
				'.constant('ojpro').'questionlist.ojquestionid = '.constant('ojpro').'link.ojquestionid
				)
			WHERE '.constant('ojpro').'link.ojclassid IN ('.implode(',',$ojclassid).')
			AND '.constant('ojpro').'link.ojquestionid NOT IN ( 
				SELECT ojquestionid FROM 
				'.constant('ojdb').'error 
				WHERE '.constant('ojdb').'error.id=?
				)			
			AND '.constant('ojpro').'link.ojquestionid!=?			
			ORDER BY rand()
			LIMIT 1
			';			
			$st = $conn2->prepare($q);	
			$st->bindParam(1,$_USER['id']);	
			$st->bindParam(2,$ansid);
			$st->execute();
			foreach($st->fetchAll() as $questionlist);			
			if($st->rowCount()==0)//无错题，无没有的，做错的最多的
			{
				$_type='max';	
				$q='SELECT *
				FROM '.constant('ojdb').'link
				INNER JOIN '.constant('ojdb').'error  ON (
					'.constant('ojpro').'error.ojquestionid = '.constant('ojpro').'link.ojquestionid
					AND '.constant('ojpro').'error.id = ?
					AND '.constant('ojpro').'error.nexttime <?
					)
				INNER JOIN '.constant('ojdb').'questionlist  ON (
					'.constant('ojpro').'questionlist.ojquestionid = '.constant('ojpro').'link.ojquestionid
					)
				WHERE '.constant('ojpro').'link.ojquestionid!=?
				AND '.constant('ojpro').'link.ojclassid IN ('.implode(',',$ojclassid).')
				ORDER BY '.constant('ojpro').'error.maxtimes ASC
				LIMIT 1
				';		
				$st = $conn2->prepare($q);					
				$st->bindParam(1,$_USER['id']);		
				$st->bindParam(2,get_time());
				$st->bindParam(3,$ansid);	
				$st->execute();
				foreach($st->fetchAll() as $questionlist);
				if($st->rowCount()==0)//无错题，无没有的，不用做错的最多的，随机做
				{
					$_type='rand';	
					$q='SELECT *
					FROM '.constant('ojdb').'link
					INNER JOIN '.constant('ojdb').'questionlist  ON (
						'.constant('ojpro').'questionlist.ojquestionid = '.constant('ojpro').'link.ojquestionid
						)
					WHERE '.constant('ojpro').'link.ojquestionid!=?
					AND '.constant('ojpro').'link.ojclassid IN ('.implode(',',$ojclassid).') 			
					ORDER BY rand()
					LIMIT 1
					';					
					$st = $conn2->prepare($q);	
					$st->bindParam(1,$ansid);
					$st->execute();
					foreach($st->fetchAll() as $questionlist);	
				}
			}	
		}
	}
	echo json_encode(array(	'times'=>$questionlist['times']!=NULL?$questionlist['times']:0,
							'maxtimes'=>$questionlist['maxtimes']!=NULL?$questionlist['maxtimes']:0,
							'check'=>$check,
							'ans'=>($check==false)?$questionlist['ans']:NULL,
							'type'=>$_type,
							'ojquestionid'=>$questionlist['ojquestionid'],
							'ojquestionaddid'=>$questionlist['ojquestionaddid'],
							'ojclassid'=>json_encode($ojclassid),
							'ojclassid_self'=>$questionlist['ojclassid'],
							'question'=>$questionlist['question'],
							'questiontype'=>$questionlist['questiontype'],
							"option"=>json_decode($questionlist['option']),
							"source"=>$questionlist['source']
							)
					)	
?>
<?php 
	include_once("../tools/head.php");
	$ojclassid=$_GET[ojclassid];
	$ojclassname=$_GET[ojclassname];
	print_head('在线测评',true,true,true);
	exit();
?>
<div class="topnav">
	<?php show_logo('');?>
	<?php show_user($_USER);?>
	<?php add_herf('general','ojall');?> 
	<?php add_herf('general','ojlogs');?>
	<?php add_herf('general','oj','active');?>
</div>
<script language="javascript" src="oj_showquestion.js"></script>
<?php if($_GET['id']==''){?>
<script language="javascript">
addload(function (){showquestion = new showquestion_function(document.getElementById('question'),'<?php echo add_herf("general","login",0,"",1)?>');loadxmldoc('oj_checkquestion.php?questionid=rand&ansid=no&ojclassid=<?php echo $ojclassid?>',function (data){showquestion.dofordata(data);});});
</script>
<?php }else{?>
<script language="javascript">
addload(function (){showquestion = new showquestion_function(document.getElementById('question'),'<?php echo add_herf("general","login",0,"",1)?>');loadxmldoc('oj_checkquestion.php?questionid=<?php echo $_GET["id"]?>&ansid=no&ojclassid=<?php echo $ojclassid?>',function (data){showquestion.dofordata(data);});});
</script>
<?php }?>
<div id='question' align="center">
</div>
<script type="text/javascript">
document.onkeydown = function (event) 
{
	var e = event || window.event || arguments.callee.caller.arguments[0];
	if (e && e.keyCode == 13) 
	{
        document.getElementById("button").click();   
	}
};
</script>
<?php print_tail()?>
//此文档相对独立不依赖缓存数据全部由后台直接提供
function showquestion_function (area,returnaddr,clean) 
{
var t;
var question_struct;
var returnaddr;
this.question_struct=area;
if(clean==true)
	this.question_struct.innerHTML='';
this.returnaddr=returnaddr;	
this.dofordata=function(data)
{
	document.getElementById('__LOAD').style.display='none';
	this.t = JSON.parse(data);  
	if(this.t.login==false)
	{
		win.alert("没有登录","","window.location.href='"+returnaddr+"'");
		return ;	
	}
	if(this.t.check==false)
	{
		win.alert("您做错了","","");
		setTimeout(function(){win.close()},1000);
		this.t.error=this.t.error-1;
	}
	if(this.t.check==true)
	{
		win.alert("您做对了","","");
		setTimeout(function(){win.close()},800);
	}
	this.question_struct.innerHTML='';
	if(this.t.error<0)
	{
		var div=document.createElement("div") ;
		div.innerHTML='错过'+(-this.t.error)+'遍了';
		div.setAttribute('id','error');
		this.question_struct.appendChild(div);
		div=null;
	}
	var op=document.createElement("input") ;
	op.setAttribute("type","hidden"); 	
	op.setAttribute("id","hidden"); 
	op.value=JSON.stringify({ansid:this.t.ojquestionid,ojclassid:this.t.ojclassid,id:this.question_struct.id,returnaddr:this.returnaddr,questiontype:this.t.questiontype});
	this.question_struct.appendChild(op);
	op=null;
	var qtitle=document.createElement("div");
	qtitle.setAttribute('id','qtitle');
	qtitle.setAttribute('class','h56');
	qtitle.innerHTML="#"+this.t.ojquestionid+":"+this.t.question;
	this.question_struct.appendChild(qtitle);
	qtitle=null;
	if(this.t.questiontype==1)
	{
		var option=document.createElement("div");
		option.setAttribute('id','option');
		option.setAttribute('class','h56');
		this.question_struct.appendChild(option);
		for(var i=0;i<this.t.option.length;i++)
		{
			var op=document.createElement("input") ;
			op.setAttribute("type","radio"); 	
			op.setAttribute("name","option");
			op.setAttribute("class","question");
			op.setAttribute("value",this.t.option[i]['option']);
			option.appendChild(op);
			op=null;
			op=document.createElement("b") ;
			op.setAttribute("class","h56"); 	
			op.innerHTML=this.t.option[i]['option']+':'+this.t.option[i]['value'];
			option.appendChild(op);
			op=null;
			option.innerHTML+="<br>";
		}	 
	}
	if(this.t.questiontype==2)
	{
		var op=document.createElement("input") ;
		op.setAttribute("type","text"); 	
		op.setAttribute("id","ans"); 	
		op.setAttribute("class","h56 ans");
		this.question_struct.appendChild(op);
		op.focus();
		op=null;
	}
	option=null;
	get_and_showuser(this.question_struct,this.t.ojquestionaddid,'90%',null);	
	var source=document.createElement("div");
	source.setAttribute('id','source');
	source.setAttribute('class','h56');
	source.innerHTML="来源："+this.t.source+';'+this.t.type;
	this.question_struct.appendChild(source);
	source=null;
	var button=document.createElement("input");
	button.setAttribute('id','button');
	button.setAttribute('class','button button1');
	button.setAttribute('type','button');
	button.setAttribute('value','下一题');
	button.onclick=function(event)
	{
		var parent=event.target.parentNode;
		var buf=parent.getElementsByTagName('input');
		var message;
		for(var i=0;i<buf.length;i++)
			if(buf[i].id=='hidden')
				message=JSON.parse(buf[i].value);
		var ans;
		if(message.questiontype==1)
		{
			var x = parent.getElementsByClassName("question");
			var i;
			for (i = 0; i < x.length; i++) 
				if(x[i].checked==true)
					ans=x[i].value;
		}	
		if(message.questiontype==2)
		{
			var x = parent.getElementsByClassName("ans");
			for (i = 0; i < x.length; i++) 
				if(x[i].id=='ans')
					ans=x[0].value;
		}
		console.log(ans);
		loadxmldoc("oj_checkquestion.php?questionid=rand&ansid="+message.ansid+"&ojclassid="+message.ojclassid+"&ans="+ans,
		function (data)
		{
			if(showquestion==null)
				var showquestion = new showquestion_function(document.getElementById(message.id),message.returnaddr);
			showquestion.dofordata(data);
		});
	}
	this.question_struct.appendChild(button);
	if(this.t.ans!=null)
	{
		var ans=document.createElement("div");
		ans.setAttribute('id','ans');
		ans.setAttribute('class','h56');
		ans.id=this.t.ans;
		ans.innerHTML='释放答案';
		ans.onclick=function(event){event.target.innerHTML=event.target.id}
		this.question_struct.appendChild(ans);
		ans=null;	
	}
	button=null;	
}
this.getans=function()
{
	if(this.t.questiontype==1)
	{
		var ans;
		var x = this.question_struct.getElementsByClassName("question");
		var i;
		for (i = 0; i < x.length; i++) 
			if(x[i].checked==true)
				return x[i].value;
	}	
	if(this.t.questiontype==2)
	{
		var ans;
		var x = this.question_struct.getElementsByClassName("ans");
		return x[0].value;
	}
}
}
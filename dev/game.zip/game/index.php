<?php
	include_once("../tools/jry_wb_includes.php");
	jry_wb_print_head("小游戏中心",false,true,true);
?>
<div class="jry_wb_top_toolbar">
	<?php jry_wb_print_logo(false);?>
	<?php if($jry_wb_login_user['id']!=-1)jry_wb_show_user($jry_wb_login_user);?>	
	<?php jry_wb_print_href('game','active');?>
	<a id='where' style="background-color:#0066FF;">您正在 /root</a>	
</div>
<script language="javascript" src="chenge.js"></script>
<div  style="width:100%;float:left;height:auto;" id="all" class="jry_wb_left_toolbar">
    <div id="menu" class="jry_wb_left_toolbar_left" style="float:left">
        <div class="jry_wb_left_toolbar_left_list_default" onClick="fresh();">刷新页面</div>
        <?php 
			@$conn2=jry_wb_connect_database();
			$st = $conn2->prepare("SELECT * FROM ".constant("jry_wb_database_game")."list where father=? ORDER BY name ASC");
			$name="root";
			$st->bindParam(1,$name);
			$st->execute();
			$i=0;
			foreach($st->fetchAll()as $list)
			{
		?>
		<div class="<?php echo (($i%2)?'jry_wb_left_toolbar_left_list_2':'jry_wb_left_toolbar_left_list_1');?>" onClick="chenge('<?php echo constant("jry_wb_host").$list[url]?>','<?php echo $list[name]?>');"><?php echo $list[name]?></div>	
        <?php $i++;}?>
	</div>
    <div id="content" style="float:left;height:auto; width:auto">
    	<iframe src="" width="100%" height="90%"  id="show" seamless="seamless" frameborder="0"></iframe>
    </div>
</div>
<?php jry_wb_print_tail();?>
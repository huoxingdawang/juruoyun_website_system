var __src=null;
var __name=null;
function chenge_width()
{
    document.getElementById("content").style.width=document.body.clientWidth-220+"px";
}
function chenge(src,name)
{
	if(src==null||name==null)
		return;	
    __src=src;__name=name;
    document.getElementById("show").src=src;
    document.getElementById("where").innerHTML="您正在   "+name;
    chenge_width();
}
function fresh()
{
	if(__src==null||__name==null)
		return;
	chenge(__src,__name);
	chenge_width();
}
jry_wb_add_onresize(chenge_width);
jry_wb_add_load(function(){window.onresize();});
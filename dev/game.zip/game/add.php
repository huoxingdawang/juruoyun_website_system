<?php
	include_once("../tools/jry_wb_includes.php");
	jry_wb_print_head("游戏",true,false,false);
	$fen=$_POST[fen];
	$name=$_POST[name];
	@$conn2=jry_wb_connect_database();
	$st = $conn2->prepare("SELECT * FROM ".constant("jry_wb_database_game")."fen where id=? and game_name=? LIMIT 1");
	$st->bindParam(1,$jry_wb_login_user[id]);
	$st->bindParam(2,$name);
	$st->execute();
	foreach($st->fetchAll()as $grade);
	$add="";
	if($grade[id]=='')
	{
		$add.="您开启了新游戏<br>";
		$st = $conn2->prepare("INSERT INTO ".constant('jry_wb_database_game')."fen (fen,id,game_name) VALUES (?,?,?)");
		$st->bindParam(1,$fen);
		$st->bindParam(2,$jry_wb_login_user[id]);
		$st->bindParam(3,$name);		
		$st->execute();	
	}
	else if($fen>$grade[fen])
	{
		$add.="您打破了您的最高分，新的最高分为".$fen."<br>";
		$st = $conn2->prepare("update ".constant('jry_wb_database_game')."fen set fen=? where id=? and game_name=? LIMIT 1");
		$st->bindParam(1,$fen);
		$st->bindParam(2,$jry_wb_login_user[id]);
		$st->bindParam(3,$name);
		$st->execute();
	}
	add_green_money($jry_wb_login_user[id],max(0,ceil($fen/3)));
	$add.="绿币增加 ".max(0,ceil($fen/3));
	jry_wb_print_tail(false);
?>
<script language=javascript>jry_wb_beautiful_alert.alert('游戏结束','<?php echo $add;?>',"self.location=document.referrer;");</script>

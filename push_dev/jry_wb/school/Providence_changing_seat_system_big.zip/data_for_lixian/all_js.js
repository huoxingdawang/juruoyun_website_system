function loadxmldoc(__url,func,array,tong)
{
	if(tong==null)
		tong=true;
	var xmlhttp;
	loading_on();
	if(window.XMLHttpRequest)
	{
		// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// IE6, IE5 浏览器执行代码
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	var clearTO=setTimeout(function()  /*重点，在请求发布后开始设置setTimeout，如果请求状态不成功也就是readyState != 4 那么setTimeout将会在5秒后运行，并弹出信息提示，要是请求成功，将会清除该setTimeout*/
	{
		xmlhttp.abort(); //终止XMLHttpRequest对象
		win.alert("网络异常","请您刷新页面或稍后再试");
	},20000);	
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			clearTimeout(clearTO);
			var ajaxLoadedData=xmlhttp.responseText;
			func(ajaxLoadedData);
			connect_special_delate();
		}
	}
	xmlhttp.open("POST",__url,tong);
	if(tong)
		xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
	var data='';
	if(typeof array=='object'&&array!=null)
	{
		var i=0;
		for(;i<array.length-1;i++)
			data+=array[i].name+'='+array[i].value+'&';
		data+=array[i].name+'='+array[i].value;
	}	
	xmlhttp.send(data);
}
var __isplaying=false;
var __playing=null;
var __video_bigbuf={'x':0,'y':0};
function beautiful_video(video_old)
{
	var video_bigbuf={'x':0,'y':0};
	var video_body=document.createElement("div");video_old.parentElement.insertBefore(video_body,video_old);
	video_body.className="video_body";
	video_bigbuf.x=video_body.style.width=video_old.style.width==''?document.defaultView.getComputedStyle(video_old,null)['width']:video_old.style.width;
	var video=video_old;
	video_old.parentElement.removeChild(video_old);video_body.appendChild(video);
	video_old=null;
	video.style.width="100%";
	video.setAttribute("controls","");
	if(ispc())
	{
		video.removeAttribute("controls");
		var buttom_bar=document.createElement("div");video_body.appendChild(buttom_bar);
		buttom_bar.className="buttom_bar";
		buttom_bar.style.display='none';
		var start_button=document.createElement("div");buttom_bar.appendChild(start_button);
		start_button.className="video_button fa fa-play";
		var progress_bar=add_progress(buttom_bar,"50%",video.currentTime/video.duration,parseInt(video.currentTime)+"/"+parseInt(video.duration),
			function(x)
			{
				video.currentTime=x*video.duration;
			},
			function(x)
			{
				buttom_bar.childNodes[1].childNodes[0].childNodes[1].innerText=parseInt(x*video.duration);
			},
			"video_progress_bar",true
		);
		
		var vioce_bar=add_progress(buttom_bar,"10%",video.volume,parseInt(video.volume*100)+"%",
			function(x)
			{
				update_progress(vioce_bar,video.volume=x,parseInt(video.volume*100)+"%");
			},
			function(x)
			{
				buttom_bar.childNodes[2].childNodes[0].childNodes[1].innerText=parseInt(x*100)+"%";
			},
			"video_voice_bar",false
		);
		var full_button=document.createElement("div");buttom_bar.appendChild(full_button);
		full_button.className="video_button fa ";
		if(document.webkitIsFullScreen)
		{
			full_button.className+="fa-compress";
			full_button.onclick=function()
			{
				video_body.style.width=__video_bigbuf.x;
				video_body.style.height=__video_bigbuf.y;	
				document.webkitCancelFullScreen();
			}
		}
		else
		{
			full_button.className+="fa-expand";
			full_button.onclick=function()
			{
				__video_bigbuf.x=video_body.style.width;
				__video_bigbuf.y=video_body.style.height;
				video.webkitRequestFullScreen();
			}	
		}
		document.addEventListener('webkitfullscreenchange',function(){
			video_body.onresize();
			full_button.className="video_button fa ";
			if(document.webkitIsFullScreen)
			{
				full_button.className+="fa-compress";
				full_button.onclick=function()
				{
					document.webkitCancelFullScreen();
				}
			}
			else
			{
				video_body.style.width=__video_bigbuf.x;
				video_body.style.height=__video_bigbuf.y;			
				full_button.className+="fa-expand";
				full_button.onclick=function()
				{
					video.webkitRequestFullScreen();
				}	
			}
		})
		video_body.onmouseover=function()
		{
			buttom_bar.style.display='';
			video_body.style.width=video_bigbuf.x;
			video_body.onresize();
			video.removeAttribute("controls");
			if(!document.webkitIsFullScreen)
				
			if(video.ended)
				start_button.className="video_button fa fa-play";
		};
		video_body.onmouseout=function()
		{
			buttom_bar.style.display='none';
		};
		video_ontimeupdate=video.ontimeupdate;
		video.ontimeupdate=function()
		{
			if(typeof video_ontimeupdate=="function")
				video_ontimeupdate(video);
			update_progress(progress_bar,video.currentTime/video.duration,parseInt(video.currentTime)+"/"+parseInt(video.duration));
		}
		video.onclick=start_button.onclick=function()
		{
			if(video.ended)
				video.currentTime=0;
			if(video.paused)
			{
				start_button.className="video_button fa fa-pause";
				if(__isplaying)
					__playing.pause()
				__isplaying=true;
				__playing=video;
				qq_music_player_paused=qq_music_player.__.audio.paused;
				qq_music_player.pause();
				video.play();
			}
			else
			{
				start_button.className="video_button fa fa-play";
				__isplaying=false;
				__playing=null;
				video.pause();
				if((!qq_music_player_paused)&&(qq_music_player.__.audio.paused))
					qq_music_player.play(getsync("playing").id);
			}
		}
		video.onload=video_body.onresize=video.onresize=function()
		{
			var paddingright=document.defaultView.getComputedStyle(buttom_bar,null)['paddingRight'];paddingright=parseInt(paddingright==""?"0":paddingright);
			var paddingleft=document.defaultView.getComputedStyle(buttom_bar,null)['paddingLeft'];paddingleft=parseInt(paddingleft==""?"0":paddingleft);
			var width=Math.min(video.scrollWidth,video.videoWidth/video.videoHeight*video.scrollHeight);
			var hight=video.videoHeight/video.videoWidth*width;
			buttom_bar.style.top=hight-buttom_bar.scrollHeight;
			buttom_bar.style.width=width-paddingleft-paddingright;
			video_body.style.height=hight;
			video_body.style.width=width;
	//		buttom_bar.style.top=0;
		}
		video_body.onmouseover();
	}
	
	video_body.style.width=video_bigbuf.x;
	return video_body;
}
function video_push_tanmu(video_body,text,top,type,color)
{
	var danmu_body=document.createElement("div");video_body.firstChild.after(danmu_body);
	if(type=="up_down")
	{
		danmu_body.style.left=top;
		danmu_body.className="danmu_up_down";
	}
	else
	{
		danmu_body.style.top=top;
		danmu_body.className="danmu_left_right";
	}
	danmu_body.innerHTML=text;
	danmu_body.style.color=color;
	setTimeout(function(){video_body.removeChild(danmu_body);},7000);
}/**
 * ColorPicker - pure JavaScript color picker without using images, external CSS or 1px divs.
 * Copyright © 2011 David Durman, All rights reserved.
 */
(function(window, document, undefined) {

    var type = (window.SVGAngle || document.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#BasicStructure", "1.1") ? "SVG" : "VML"),
        picker, slide, hueOffset = 15, svgNS = 'http://www.w3.org/2000/svg';

    // This HTML snippet is inserted into the innerHTML property of the passed color picker element
    // when the no-hassle call to ColorPicker() is used, i.e. ColorPicker(function(hex, hsv, rgb) { ... });
    
    var colorpickerHTMLSnippet = [
        
        '<div class="picker-wrapper">',
                '<div class="picker"></div>',
                '<div class="picker-indicator"></div>',
        '</div>',
        '<div class="slide-wrapper">',
                '<div class="slide"></div>',
                '<div class="slide-indicator"></div>',
        '</div>'
        
    ].join('');

    /**
     * Return mouse position relative to the element el.
     */
    function mousePosition(evt) {
        // IE:
        if (window.event && window.event.contentOverflow !== undefined) {
            return { x: window.event.offsetX, y: window.event.offsetY };
        }
        // Webkit:
        if (evt.offsetX !== undefined && evt.offsetY !== undefined) {
            return { x: evt.offsetX, y: evt.offsetY };
        }
        // Firefox:
        var wrapper = evt.target.parentNode.parentNode;
        return { x: evt.layerX - wrapper.offsetLeft, y: evt.layerY - wrapper.offsetTop };
    }

    /**
     * Create SVG element.
     */
    function $(el, attrs, children) {
        el = document.createElementNS(svgNS, el);
        for (var key in attrs)
            el.setAttribute(key, attrs[key]);
        if (Object.prototype.toString.call(children) != '[object Array]') children = [children];
        var i = 0, len = (children[0] && children.length) || 0;
        for (; i < len; i++)
            el.appendChild(children[i]);
        return el;
    }

    /**
     * Create slide and picker markup depending on the supported technology.
     */
    if (type == 'SVG') {

        slide = $('svg', { xmlns: 'http://www.w3.org/2000/svg', version: '1.1', width: '100%', height: '100%' },
                  [
                      $('defs', {},
                        $('linearGradient', { id: 'gradient-hsv', x1: '0%', y1: '100%', x2: '0%', y2: '0%'},
                          [
                              $('stop', { offset: '0%', 'stop-color': '#FF0000', 'stop-opacity': '1' }),
                              $('stop', { offset: '13%', 'stop-color': '#FF00FF', 'stop-opacity': '1' }),
                              $('stop', { offset: '25%', 'stop-color': '#8000FF', 'stop-opacity': '1' }),
                              $('stop', { offset: '38%', 'stop-color': '#0040FF', 'stop-opacity': '1' }),
                              $('stop', { offset: '50%', 'stop-color': '#00FFFF', 'stop-opacity': '1' }),
                              $('stop', { offset: '63%', 'stop-color': '#00FF40', 'stop-opacity': '1' }),
                              $('stop', { offset: '75%', 'stop-color': '#0BED00', 'stop-opacity': '1' }),
                              $('stop', { offset: '88%', 'stop-color': '#FFFF00', 'stop-opacity': '1' }),
                              $('stop', { offset: '100%', 'stop-color': '#FF0000', 'stop-opacity': '1' })
                          ]
                         )
                       ),
                      $('rect', { x: '0', y: '0', width: '100%', height: '100%', fill: 'url(#gradient-hsv)'})
                  ]
                 );

        picker = $('svg', { xmlns: 'http://www.w3.org/2000/svg', version: '1.1', width: '100%', height: '100%' },
                   [
                       $('defs', {},
                         [
                             $('linearGradient', { id: 'gradient-black', x1: '0%', y1: '100%', x2: '0%', y2: '0%'},
                               [
                                   $('stop', { offset: '0%', 'stop-color': '#000000', 'stop-opacity': '1' }),
                                   $('stop', { offset: '100%', 'stop-color': '#CC9A81', 'stop-opacity': '0' })
                               ]
                              ),
                             $('linearGradient', { id: 'gradient-white', x1: '0%', y1: '100%', x2: '100%', y2: '100%'},
                               [
                                   $('stop', { offset: '0%', 'stop-color': '#FFFFFF', 'stop-opacity': '1' }),
                                   $('stop', { offset: '100%', 'stop-color': '#CC9A81', 'stop-opacity': '0' })
                               ]
                              )
                         ]
                        ),
                       $('rect', { x: '0', y: '0', width: '100%', height: '100%', fill: 'url(#gradient-white)'}),
                       $('rect', { x: '0', y: '0', width: '100%', height: '100%', fill: 'url(#gradient-black)'})
                   ]
                  );

    } else if (type == 'VML') {
        slide = [
            '<DIV style="position: relative; width: 100%; height: 100%">',
            '<v:rect style="position: absolute; top: 0; left: 0; width: 100%; height: 100%" stroked="f" filled="t">',
            '<v:fill type="gradient" method="none" angle="0" color="red" color2="red" colors="8519f fuchsia;.25 #8000ff;24903f #0040ff;.5 aqua;41287f #00ff40;.75 #0bed00;57671f yellow"></v:fill>',
            '</v:rect>',
            '</DIV>'
        ].join('');

        picker = [
            '<DIV style="position: relative; width: 100%; height: 100%">',
            '<v:rect style="position: absolute; left: -1px; top: -1px; width: 101%; height: 101%" stroked="f" filled="t">',
            '<v:fill type="gradient" method="none" angle="270" color="#FFFFFF" opacity="100%" color2="#CC9A81" o:opacity2="0%"></v:fill>',
            '</v:rect>',
            '<v:rect style="position: absolute; left: 0px; top: 0px; width: 100%; height: 101%" stroked="f" filled="t">',
            '<v:fill type="gradient" method="none" angle="0" color="#000000" opacity="100%" color2="#CC9A81" o:opacity2="0%"></v:fill>',
            '</v:rect>',
            '</DIV>'
        ].join('');
        
        if (!document.namespaces['v'])
            document.namespaces.add('v', 'urn:schemas-microsoft-com:vml', '#default#VML');
    }

    /**
     * Convert HSV representation to RGB HEX string.
     * Credits to http://www.raphaeljs.com
     */
    function hsv2rgb(hsv) {
        var R, G, B, X, C;
        var h = (hsv.h % 360) / 60;
        
        C = hsv.v * hsv.s;
        X = C * (1 - Math.abs(h % 2 - 1));
        R = G = B = hsv.v - C;

        h = ~~h;
        R += [C, X, 0, 0, X, C][h];
        G += [X, C, C, X, 0, 0][h];
        B += [0, 0, X, C, C, X][h];

        var r = Math.floor(R * 255);
        var g = Math.floor(G * 255);
        var b = Math.floor(B * 255);
        return { r: r, g: g, b: b, hex: "#" + (16777216 | b | (g << 8) | (r << 16)).toString(16).slice(1) };
    }

    /**
     * Convert RGB representation to HSV.
     * r, g, b can be either in <0,1> range or <0,255> range.
     * Credits to http://www.raphaeljs.com
     */
    function rgb2hsv(rgb) {

        var r = rgb.r;
        var g = rgb.g;
        var b = rgb.b;
        
        if (rgb.r > 1 || rgb.g > 1 || rgb.b > 1) {
            r /= 255;
            g /= 255;
            b /= 255;
        }

        var H, S, V, C;
        V = Math.max(r, g, b);
        C = V - Math.min(r, g, b);
        H = (C == 0 ? null :
             V == r ? (g - b) / C + (g < b ? 6 : 0) :
             V == g ? (b - r) / C + 2 :
                      (r - g) / C + 4);
        H = (H % 6) * 60;
        S = C == 0 ? 0 : C / V;
        return { h: H, s: S, v: V };
    }

    /**
     * Return click event handler for the slider.
     * Sets picker background color and calls ctx.callback if provided.
     */  
    function slideListener(ctx, slideElement, pickerElement) {
        return function(evt) {
            evt = evt || window.event;
            var mouse = mousePosition(evt);
            ctx.h = mouse.y / slideElement.offsetHeight * 360 + hueOffset;
            var pickerColor = hsv2rgb({ h: ctx.h, s: 1, v: 1 });
            var c = hsv2rgb({ h: ctx.h, s: ctx.s, v: ctx.v });
            pickerElement.style.backgroundColor = pickerColor.hex;
            ctx.callback && ctx.callback(c.hex, { h: ctx.h - hueOffset, s: ctx.s, v: ctx.v }, { r: c.r, g: c.g, b: c.b }, undefined, mouse);
        }
    };

    /**
     * Return click event handler for the picker.
     * Calls ctx.callback if provided.
     */  
    function pickerListener(ctx, pickerElement) {
        return function(evt) {
            evt = evt || window.event;
            var mouse = mousePosition(evt),
                width = pickerElement.offsetWidth,            
                height = pickerElement.offsetHeight;

            ctx.s = mouse.x / width;
            ctx.v = (height - mouse.y) / height;
            var c = hsv2rgb(ctx);
            ctx.callback && ctx.callback(c.hex, { h: ctx.h - hueOffset, s: ctx.s, v: ctx.v }, { r: c.r, g: c.g, b: c.b }, mouse);
        }
    };

    var uniqID = 0;
    
    /**
     * ColorPicker.
     * @param {DOMElement} slideElement HSV slide element.
     * @param {DOMElement} pickerElement HSV picker element.
     * @param {Function} callback Called whenever the color is changed provided chosen color in RGB HEX format as the only argument.
     */
    function ColorPicker(slideElement, pickerElement, callback) {
        
        if (!(this instanceof ColorPicker)) return new ColorPicker(slideElement, pickerElement, callback);

        this.h = 0;
        this.s = 1;
        this.v = 1;

        if (!callback) {
            // call of the form ColorPicker(element, funtion(hex, hsv, rgb) { ... }), i.e. the no-hassle call.

            var element = slideElement;
            element.innerHTML = colorpickerHTMLSnippet;
            
            this.slideElement = element.getElementsByClassName('slide')[0];
            this.pickerElement = element.getElementsByClassName('picker')[0];
            var slideIndicator = element.getElementsByClassName('slide-indicator')[0];
            var pickerIndicator = element.getElementsByClassName('picker-indicator')[0];
            
            ColorPicker.fixIndicators(slideIndicator, pickerIndicator);

            this.callback = function(hex, hsv, rgb, pickerCoordinate, slideCoordinate) {

                ColorPicker.positionIndicators(slideIndicator, pickerIndicator, slideCoordinate, pickerCoordinate);
                
                pickerElement(hex, hsv, rgb);
            };
            
        } else {
        
            this.callback = callback;
            this.pickerElement = pickerElement;
            this.slideElement = slideElement;
        }

        if (type == 'SVG') {

            // Generate uniq IDs for linearGradients so that we don't have the same IDs within one document.
            // Then reference those gradients in the associated rectangles.

            var slideClone = slide.cloneNode(true);
            var pickerClone = picker.cloneNode(true);
            
            var hsvGradient = slideClone.getElementsByTagName('linearGradient')[0];
            
            var hsvRect = slideClone.getElementsByTagName('rect')[0];
            
            hsvGradient.id = 'gradient-hsv-' + uniqID;
            hsvRect.setAttribute('fill', 'url(#' + hsvGradient.id + ')');

            var blackAndWhiteGradients = [pickerClone.getElementsByTagName('linearGradient')[0], pickerClone.getElementsByTagName('linearGradient')[1]];
            var whiteAndBlackRects = pickerClone.getElementsByTagName('rect');
            
            blackAndWhiteGradients[0].id = 'gradient-black-' + uniqID;
            blackAndWhiteGradients[1].id = 'gradient-white-' + uniqID;
            
            whiteAndBlackRects[0].setAttribute('fill', 'url(#' + blackAndWhiteGradients[1].id + ')');
            whiteAndBlackRects[1].setAttribute('fill', 'url(#' + blackAndWhiteGradients[0].id + ')');

            this.slideElement.appendChild(slideClone);
            this.pickerElement.appendChild(pickerClone);

            uniqID++;
            
        } else {
            
            this.slideElement.innerHTML = slide;
            this.pickerElement.innerHTML = picker;            
        }

        addEventListener(this.slideElement, 'click', slideListener(this, this.slideElement, this.pickerElement));
        addEventListener(this.pickerElement, 'click', pickerListener(this, this.pickerElement));

        enableDragging(this, this.slideElement, slideListener(this, this.slideElement, this.pickerElement));
        enableDragging(this, this.pickerElement, pickerListener(this, this.pickerElement));
    };

    function addEventListener(element, event, listener) {

        if (element.attachEvent) {
            
            element.attachEvent('on' + event, listener);
            
        } else if (element.addEventListener) {

            element.addEventListener(event, listener, false);
        }
    }

   /**
    * Enable drag&drop color selection.
    * @param {object} ctx ColorPicker instance.
    * @param {DOMElement} element HSV slide element or HSV picker element.
    * @param {Function} listener Function that will be called whenever mouse is dragged over the element with event object as argument.
    */
    function enableDragging(ctx, element, listener) {
        
        var mousedown = false;

        addEventListener(element, 'mousedown', function(evt) { mousedown = true;  });
        addEventListener(element, 'mouseup',   function(evt) { mousedown = false;  });
        addEventListener(element, 'mouseout',  function(evt) { mousedown = false;  });
        addEventListener(element, 'mousemove', function(evt) {

            if (mousedown) {
                
                listener(evt);
            }
        });
    }


    ColorPicker.hsv2rgb = function(hsv) {
        var rgbHex = hsv2rgb(hsv);
        delete rgbHex.hex;
        return rgbHex;
    };
    
    ColorPicker.hsv2hex = function(hsv) {
        return hsv2rgb(hsv).hex;
    };
    
    ColorPicker.rgb2hsv = rgb2hsv;

    ColorPicker.rgb2hex = function(rgb) {
        return hsv2rgb(rgb2hsv(rgb)).hex;
    };
    
    ColorPicker.hex2hsv = function(hex) {
        return rgb2hsv(ColorPicker.hex2rgb(hex));
    };
    
    ColorPicker.hex2rgb = function(hex) {
        return { r: parseInt(hex.substr(1, 2), 16), g: parseInt(hex.substr(3, 2), 16), b: parseInt(hex.substr(5, 2), 16) };
    };

    /**
     * Sets color of the picker in hsv/rgb/hex format.
     * @param {object} ctx ColorPicker instance.
     * @param {object} hsv Object of the form: { h: <hue>, s: <saturation>, v: <value> }.
     * @param {object} rgb Object of the form: { r: <red>, g: <green>, b: <blue> }.
     * @param {string} hex String of the form: #RRGGBB.
     */
     function setColor(ctx, hsv, rgb, hex) {
         ctx.h = hsv.h % 360;
         ctx.s = hsv.s;
         ctx.v = hsv.v;
         
         var c = hsv2rgb(ctx);
         
         var mouseSlide = {
             y: (ctx.h * ctx.slideElement.offsetHeight) / 360,
             x: 0    // not important
         };
         
         var pickerHeight = ctx.pickerElement.offsetHeight;
         
         var mousePicker = {
             x: ctx.s * ctx.pickerElement.offsetWidth,
             y: pickerHeight - ctx.v * pickerHeight
         };
         
         ctx.pickerElement.style.backgroundColor = hsv2rgb({ h: ctx.h, s: 1, v: 1 }).hex;
         ctx.callback && ctx.callback(hex || c.hex, { h: ctx.h, s: ctx.s, v: ctx.v }, rgb || { r: c.r, g: c.g, b: c.b }, mousePicker, mouseSlide);
         
         return ctx;
    };

    /**
     * Sets color of the picker in hsv format.
     * @param {object} hsv Object of the form: { h: <hue>, s: <saturation>, v: <value> }.
     */
    ColorPicker.prototype.setHsv = function(hsv) {
        return setColor(this, hsv);
    };
    
    /**
     * Sets color of the picker in rgb format.
     * @param {object} rgb Object of the form: { r: <red>, g: <green>, b: <blue> }.
     */
    ColorPicker.prototype.setRgb = function(rgb) {
        return setColor(this, rgb2hsv(rgb), rgb);
    };

    /**
     * Sets color of the picker in hex format.
     * @param {string} hex Hex color format #RRGGBB.
     */
    ColorPicker.prototype.setHex = function(hex) {
        return setColor(this, ColorPicker.hex2hsv(hex), undefined, hex);
    };

    /**
     * Helper to position indicators.
     * @param {HTMLElement} slideIndicator DOM element representing the indicator of the slide area.
     * @param {HTMLElement} pickerIndicator DOM element representing the indicator of the picker area.
     * @param {object} mouseSlide Coordinates of the mouse cursor in the slide area.
     * @param {object} mousePicker Coordinates of the mouse cursor in the picker area.
     */
    ColorPicker.positionIndicators = function(slideIndicator, pickerIndicator, mouseSlide, mousePicker) {
        
        if (mouseSlide) {
            slideIndicator.style.top = (mouseSlide.y - slideIndicator.offsetHeight/2) + 'px';
        }
        if (mousePicker) {
            pickerIndicator.style.top = (mousePicker.y - pickerIndicator.offsetHeight/2) + 'px';
            pickerIndicator.style.left = (mousePicker.x - pickerIndicator.offsetWidth/2) + 'px';
        } 
    };

    /**
     * Helper to fix indicators - this is recommended (and needed) for dragable color selection (see enabledDragging()).
     */
    ColorPicker.fixIndicators = function(slideIndicator, pickerIndicator) {

        pickerIndicator.style.pointerEvents = 'none';
        slideIndicator.style.pointerEvents = 'none';
    };

    window.ColorPicker = ColorPicker;

})(window, window.document);
// JavaScript Document
var cookie = 
{
	set:function(key,val,time)//设置cookie方法
	{
		var date=new Date(); //获取当前时间
		var expiresDays=time;  //将date设置为n天以后的时间
		date.setTime(date.getTime()+expiresDays*1000); //格式化为cookie识别的时间
		document.cookie=key + "=" + escape(val) +";expires="+date.toGMTString()+";path=/";  //设置cookie
	},
	get:function(key)
	{
		/*获取cookie参数*/
		var getCookie = document.cookie.replace(/[ ]/g,"");  //获取cookie，并且将获得的cookie格式化，去掉空格字符
		var arrCookie = getCookie.split(";")  //将获得的cookie以"分号"为标识 将cookie保存到arrCookie的数组中
		var tips;  //声明变量tips
		for(var i=0;i<arrCookie.length;i++){   //使用for循环查找cookie中的tips变量
			var arr=arrCookie[i].split("=");   //将单条cookie用"等号"为标识，将单条cookie保存为arr数组
			if(key==arr[0]){  //匹配变量名称，其中arr[0]是指的cookie名称，如果该条变量为tips则执行判断语句中的赋值操作
				tips=arr[1];   //将cookie的值赋给变量tips
				break;   //终止for循环遍历
			}
		}
		return tips;
	},
	delete:function(key)
	{
		var date = new Date(); //获取当前时间
		date.setTime(date.getTime()-10000); //将date设置为过去的时间
		document.cookie = key + "=v; expires =" +date.toGMTString();//设置cookie
	}
};function copytoclipboard(s)
{
	if(window.clipboardData)
		window.clipboardData.setData('text',s);
	else
	{
		(function(s){
			document.oncopy=function(e)
			{
				e.clipboardData.setData('text',s);
				e.preventDefault();	
				document.oncopy=null;
			}
		})(s);
		document.execCommand('Copy');
	}
}function set_div_to_textarea(dom)
{
	dom.setAttribute('contenteditable','true');
	dom.onkeydown = function (ev) 
	{
		var oEvent = ev || event;
	}
}
function set_text_to_div(dom,text)
{
	text=text.replace(/&/g,"&amp;");
	text=text.replace(/</g,"&lt;");
	text=text.replace(/>/g,"&gt;");
	text=text.replace(/"/g,"&quot;");
	text=text.replace(/'/g,"&apos;");
	text=text.replace(/￠/g,"&cent;");
	text=text.replace(/£/g,"&pound;");
	text=text.replace(/¥/g,"&yen;");
	text=text.replace(/€/g,"&euro;");
	text=text.replace(/§/g,"&sect;");
	text=text.replace(/©/g,"&copy;");
	text=text.replace(/®/g,"&reg;");
	text=text.replace(/™/g,"&trade;");
	text=text.replace(/×/g,"&times;");
	text=text.replace(/÷/g,"&divide;");	
	text=text.replace(/\n/g,"<br>");
	text=text.replace(/ /g,"&nbsp;");
	dom.innerHTML=text;
}
function get_div_to_text(dom)
{
	text=dom.innerHTML;
	text=text.replace(/&amp;/g	,"&");
	text=text.replace(/&lt;/g	,"<");
	text=text.replace(/&gt;/g	,">");
	text=text.replace(/&quot;/g	,'"');
	text=text.replace(/&apos;/g	,"'");
	text=text.replace(/&cent;/g	,"￠");
	text=text.replace(/&pound;/g,"£");
	text=text.replace(/&yen;/g	,"¥");
	text=text.replace(/&euro;/g	,"€");
	text=text.replace(/&sect;/g	,"§");
	text=text.replace(/&copy;/g	,"©");
	text=text.replace(/&reg;/g	,"®");
	text=text.replace(/&trade;/g,"™");
	text=text.replace(/&times;/g,"×");
	text=text.replace(/&divide;/g,"÷");	
	text=text.replace(/<br>/g	,"\n");
	text=text.replace(/&nbsp;/g	," ");
	text=text.replace(/&#9;/g	,"\t");
	text=text.replace(/<div>/g	,"\n");
	text=text.replace(/<\/div>/g,"");
	text=text.replace(/<span style="white-space: pre;">	<\/span>/g,"\t");
	return text;
}function getpath(s) 
{
	var m = new Image();
	m.src=s;
	return m.src;
}function include_once(src)
{
	src=getpath(src);
	var test=document.getElementsByTagName('script');
	var flag=false;
	for(var i=0,n=test.length;i<n;i++)
		if(test[i].src==src)
			return true;
	var myscript = document.createElement('script');document.body.appendChild(myscript);
	myscript.src = src;myscript.type = 'text/javascript';myscript.defer = true;
	return false;
}
function include_css(src)
{
	src=getpath(src);
	var test=document.getElementsByTagName('link');
	var flag=false;
	for(var i=0,n=test.length;i<n;i++)
		if(test[i].type=='text/css'&&test[i].href==src)
			return true;
	var mylink = document.createElement('link');document.body.appendChild(mylink);
	mylink.href = src;mylink.type = 'text/css';mylink.rel='stylesheet'
	return false;
}// JavaScript Document
Array.prototype.indexOF = function(func,b)
{
	for (var i=0,n=this.length; i<n; i++)
		if (func(this[i],b))
			return i;
	return -1;
};function vegetable()
{
console.info("%c"+ 
"                             UM.\n"+
"                            J@B@1                                                                    iO@1\n"+
"                           Y@@@B@BB.                                                              7B@B@B@\n"+
"                          :@B@i,B@B@O                                                          ,Z@B@B@B@Br\n"+
"                          @B@q   i@B@BS                                                      7@B@@@O5vMB@q\n"+
"                         8@@B      LB@B@i                                                  FB@@@BNjYjLE@B@\n"+
"                        ,B@B:        0@@@Z                                               P@B@BM1JJ125JPB@B\n"+
"                        B@BB          :@B@B                                            XB@B@Z2LuU52F2u2@B@.\n"+
"                       :@B@             @@@B:                                        v@B@B8uJj51F1525uUB@B7\n"+
"                       @B@O              0@@B.               ..::ir7vvYUuU777r::.   B@B@OULU2F2F151F11Y@B@S\n"+
"                       B@B,               8B@B  :ruXMB@B@B@B@B@B@B@B@B@B@@@B@B@B@B@B@B@5Jj1211F1F1F2FUJO@BB\n"+
"                      U@B@                 @B@B@B@B@B@@@B@B@B@MMqPS5JuYL7rq@B@OBB@B@B8Yu211F1515251515YGB@@\n"+
"                      @B@u                 v@@@@MSur:.                    LB@MvvjJuU5YU252F1F1F25251F2uX@@@\n"+
"                      @@@.                                                N@BML2U2UUU12F15252525251515Jk@@B\n"+
"                     r@B@                                                 YB@Bju52121252515252F15251F2u5@B@\n"+
"                     PB@B                                                  @@@PYUF151F25151F152F2F1F15jF@@B\n"+
"                     @@BS                                                  N@@@UJ2F25252F251525151F1F1u5@B@\n"+
"                     @@@7                                                   B@B@5Yj12F152F1F1F25252515jFB@B\n"+
"                     B@Bi                                                    M@B@O2Luu52525212F151121UY1@B@7\n"+
"                    O@B@:                                                     v@B@BMSuYJJuuUu2u2uujjYJJXB@B@M\n"+
"                  7B@B@,                                                        1B@@@B@GPF1uujuu21PNMB@B@B@B@@\n"+
"                 qB@B2                                                            i8B@B@B@B@B@@@@@B@B@B@q: @@@B\n"+
"                MB@B:                                                                 7SBB@B@B@B@B@Zu:      @B@B\n"+
"               ZB@B.                                              ,v.                                        @B@L\n"+
"              LB@B,                         Y7                    @B@Bu                                      7@B@\n"+
"   :B@B@@B2:  @@B7                         @B@Z                   r@B@B@BP:                                   B@BE\n"+
"    BB@@@B@B@B@BE                        r@B@B                       7@B@B@B@Ou:                              iB@B\n"+
"         :uM@@B@@2.           :7::::ivk@B@B@0                           :5B@B@B@B@B@B@G.                       @B@i\n"+
"            BB@@@B@@         :@B@B@@@B@B@@1                                 .i5M@B@B@@@5                       M@@2\n"+
"            B@B ,@B1          L0EZZG0F7:                                            .:,                        uB@MrP@M7\n"+
"           2@B@                                                                                               ,O@B@B@B@B\n"+
"           @B@1                                                     :@B@@@r                                :@@@@B@BL:,,\n"+
"           B@Bi                         :2ZS;                      :@B@B@B@r                               L@B@B@BU\n"+
"           @B@.                        @@@B@B@                     vB@B@B@B5                                   @B@i\n"+
"           B@B                        7B@B@B@BM                     OB@B@B@                                   ,B@B\n"+
"           @B@                         @B@B@@@i                       rL7.                                    B@BM\n"+
"           B@B7.:                       NB@@M.                                                               .@B@.\n"+
"  .;JEB@@@B@B@B@B@.                                                                                       .  @B@u\n"+
"@@@B@B@B@B@@@B@18U                                                                                      :B@B@B@BU,\n"+
"7@BOui.    ,@@B                                                                                          SP@B@B@B@B@Or\n"+
"            @@@U                                                                                           B@BJ.YO@B@B@i\n"+
"            r@B@                                                                                         :B@Bk     .k@B@\n"+
"             B@B@                                                                                       LB@@k         2i\n"+
"              B@BM                                      .7jXEGqF7:                                     OB@@L\n"+
"              .B@BM                                   .B@B@B@B@B@B@.                                 :@B@B:\n"+
"               .B@B@                                   @@MYr::ivG@B                                .M@B@G\n"+
"                 B@@@S                                                                           ,MB@B@,\n"+
"                  v@@@BF                                                                      .1B@B@Br\n"+
"                    2@@B@BL                                                                ,FB@@@B8,\n"+
"                      r@B@B@BF,                                                        :YBB@B@B@B\n"+
"                         L@B@B@B@P7,                                           .ivXB@B@B@B@B@M@B@\n"+
"                            ,1B@B@B@B@@@BOP2L7i:,.              ..,:i7LSNB@@B@B@@@B@B@B@Z5v;.LB@@\n"+
"                              @B@OEB@B@@@B@B@B@B@B@B@B@B@@@B@B@B@B@B@@@B@B@B@B@BM0SJ7i::::i:,u@B@\n"+
"                              B@Bu ::i;7vu2XNGOMB@B@BMB@B@B@B@B@B@@@B1UFuj77ii:::::::iir;r;i.YB@B\n"+
"                              @B@L.:i:i:i::::::::::..Y@B@BMYi:i;SB@B@N:.::i:iirir;r;rii::::ivO@B@\n"+
"                              B@@X::,::::iirir;riri:E@B@1         ,@B@Br:;;r;rii:i::::i7JEB@@@@@B\n"+
"                              @@@B@BBq5v7ii:::::::.2@@@i  ..,..     @B@@,,:::::irv2XMB@B@B@B@2@B@:\n"+
"                             .B@BBB@@@B@B@B@BMNP5u7@B@1 .,,:,,  :.   @B@P50MB@B@B@B@B@@@BS:   @@B1\n"+
"                             E@B@   ijGB@B@B@B@B@B@B@Bi .,:,,..@@B@7 B@B@B@B@B@B@BM57.        kB@B\n"+
"                            .@B@:          .,ivu5Nq@B@u  ..,.. SB@B@@@B@PL7i,                 ,@B@\n"+
"                            @@@8                   i@B@:    .     :B@B@@                       B@@2\n"+
"                          i@@@@                     0@B@u          B@@B.                       vB@B\n"+
"                         ,@B@G                       L@B@BOv:.:iFB@B@M                          @B@Bi\n"+
"                          vNi                          S@@B@B@B@B@BM:                            MB@N\n"+
"                                                          758BMqJ,\n"+
"\n"+
"                .  YO.               vq                            :G       Z:\n"+
"       SqOMBB@B@Br @@r rBE           @B     B@@@@@B@ONX8k    i::::.OB1.:::.u@O.::::i           @B@B@U:@@B@@BPEBu\n"+
"        B@@NB@k.    5@i  uB@E.        BM     1U2uUJvirB@@Z   r@@B@B@@@B@B@B@B@B@@@B@Bi   LB@B@1 BX :@k uLLLvr@BJ:\n"+
"            iB      iBi    7@     .@M8@BGMZZ         @@F            ,B       Pi          v@  Bq @i v@        B@\n"+
"       vuL7r8@S7vJL7N@Z7LLri;72.   F7@Bvvv@@       @BX         @@@B@B@@@@@B@@@B@B@B      7@  @F Bi @q  @B@Bu @B\n"+
"       N@B@G@@@8@BBOMB@G@BMNXG@,     B@   @@      .Bk          .:u;    i@:      Zv       7@  Bk @,;@  ,BY @B B@\n"+
"            r@       @G     5.      ,@v   BZ :::,.r@E .::i,      @B     B@    .@BL       7@  @F B:i@. .@  @M @B\n"+
"            7B: ,vO, @@   iB@:      @B   7@:MB@B@B@@@B@B@BM       @@.    B:  2@q         7@  BS @i 0@  B. @O B@\n"+
"       ,r2EBB@B@B@Bi G@  @BB        B@   @B        @S              :    r@   ..          7B  @F @7  B7 @  @B @B\n"+
"       E@B@UOBr       @B@Bi          L@0PB        .BZ        .@B@B@B@B@B@B@B@B@B@B@B@,   r@  BF @i  @G B@B@B B@\n"+
"            7@,      kB@U    ;r        @@@.       .@Z                GBuL@iBBi           vB@B@q BP:5@7 @u,.  @B\n"+
"            LBi   YB@BrB@    @@       @B:L@Br      BM             .M@B  rB  rB@J         v@. Pi @XZ8r  .     B@\n"+
"        .   G@i B@BM.  ,B@,  @B    iB@B    N, 7r..q@k         ,LB@B8    J@,   i@B@B1r           Br           @@\n"+
"         MB@B@B  ,i       B@B@B,    B@:        @B@B@F         .@BB:      P@i      :OBZ          .@U       B@B@B:\n"+
"                          .ll                                           rB.                     :\n"
,"color:#00ff00;"
);
}function mail_test(mail)
{
//	var temp = document.getElementById("text1");
	var myreg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	if(!myreg.test(mail))
		return false;
	return true;
}
var move=new function()
{
    this.flag = false;
	this.boxes=new Array();
    this.down=function(event)
	{
		if(this.flag==false)
		{
			this.flag = true;
			var touch ;
			if(event.touches)
				touch = event.touches[0];
			else 
				touch = event;
			//console.log(touch);
			this.from=event.target;
			this.movebuf=event.target.cloneNode();
			this.movebuf.id='movebuf';
			this.movebuf.style.position='absolute';
			this.movebuf.style.background='#66FFFF';
			this.movebuf.innerHTML='moving+'+this.from.innerHTML;
			
			var scrollTop=document.body.scrollTop==0?document.documentElement.scrollTop:document.body.scrollTop;
			var scrollLeft=document.body.scrollLeft==0?document.documentElement.scrollLeft:document.body.scrollLeft;
			this.x	= touch.clientX+(scrollLeft)-(this.movebuf.clientWidth)/2;
           	this.y 	= touch.clientY+(scrollTop)-(this.movebuf.clientHeight)/2;
			//console.log(this.x);
			//console.log(this.y);
           	this.movebuf.style.left	= this.x +"px";
           	this.movebuf.style.top 	= this.y +"px";
			this.addmove(this.movebuf);
			this.movebuf.style.zIndex=100000;
			document.body.appendChild(this.movebuf);
		}
    }
    this.move=function(event)
	{
        if(this.flag)
		{
			this.flag = true;
            var touch ;
            if(event.touches)
                touch = event.touches[0];
			else 
                touch = event;
			var scrollTop=document.body.scrollTop==0?document.documentElement.scrollTop:document.body.scrollTop;
			var scrollLeft=document.body.scrollLeft==0?document.documentElement.scrollLeft:document.body.scrollLeft;
			this.x	= touch.clientX+(scrollLeft)-(this.movebuf.clientWidth)/2;
           	this.y 	= touch.clientY+(scrollTop)-(this.movebuf.clientHeight)/2;
			this.xx=touch.clientX;
			this.yy=touch.clientY;
			//console.log(this.x);
			//console.log(this.y);
           	this.movebuf.style.left	= this.x +"px";
           	this.movebuf.style.top 	= this.y +"px";
            document.addEventListener("touchmove",function(){event.preventDefault();},false);
        }
    }
	this.drop=function(event)
	{
		//alert('drop'+this.xx+' '+this.yy);
		document.body.removeChild(this.movebuf);
		this.flag = false;
		//console.log(this.boxes);
		
		for(var i=0;i<this.boxes.length;i++)
		{
			if(	this.boxes[i].offsetLeft<this.xx&&
				this.boxes[i].offsetLeft+this.boxes[i].offsetWidth>this.xx&&
				this.boxes[i].offsetTop<this.yy&&
				this.boxes[i].offsetTop+this.boxes[i].offsetHeight>this.yy
			)
			{
				this.to=this.boxes[i];
				//console.log(this.to);
				this.to.endmove(this.from,this.to);
			}
		}
	}
	this.addmove=function(div2)
	{
		div2.addEventListener("mousedown"	,function(event){move.down(event);event.preventDefault();},false);
		div2.addEventListener("touchstart"	,function(event){move.down(event);event.preventDefault();},false);
		div2.addEventListener("mousemove"	,function(event){move.move(event);},false);
		div2.addEventListener("touchmove"	,function(event){move.move(event);},false);
		div2.addEventListener("mouseup"		,function(event){move.drop(event);},false);
		div2.addEventListener("touchend"	,function(event){move.drop(event);},false);
		div2.addEventListener("touchcancel"	,function(event){move.drop(event);},false);
	}
	this.setbox=function(div2,func)
	{
		div2.endmove=func;
		this.boxes.push(div2);
		
	}
	this.deletebox=function(div2)
	{
		var buf=this.boxes.find(function(a){return a.id==div2.id});
		this.boxes.splice(showbuf.indexOf(buf),1);
	}
}
__onload=null;
function addload(func) 
{  
  	var oldonload = __onload;  
  	if (typeof __onload!='function') 
		__onload=func;
	else 
		__onload=function(){if(oldonload)oldonload();func();};
}
var __loading_count=1;
function loading_on()
{
	__loading_count++;
	document.getElementById('__LOAD').style.display='';
}
function loading_off()
{
	__loading_count--;
	if(__loading_count<=0)
		document.getElementById('__LOAD').style.display='none';
}
function addresize(func) 
{  
  	var oldonresize=window.onresize;  
  	if (typeof window.onresize!='function')
    	window.onresize=func;
	else
    	window.onresize=function(){if(oldonresize)oldonresize();func();};
}
function addonclick(func) 
{  
  	var oldonclick=window.onclick;  
  	if (typeof window.onclick!='function')  
    	window.onclick=func;
	else 
    	window.onclick=function(event){if(oldonclick)oldonclick(event);func(event);};  
}
function addmousemove(func) 
{  
  	var oldmousemove = window.onmousemove;  
  	if (typeof window.onmousemove != 'function') 
    	window.onmousemove=func;  
	else 
    	window.onmousemove=function(event){if(oldmousemove);oldmousemove(event);func(event);};
}
function addonscroll(func) 
{  
  	var oldonscroll = window.onscroll;  
  	if (typeof window.onscroll != 'function') 
    	window.onscroll=func;  
	else 
    	window.onscroll=function(event){if(oldonscroll);oldonscroll(event);func(event);};
}function showuser(addr,user,width,float,inline)
{
	if(width==null)
		width='200px';
	if(float==null)
		float='';
	else
		float='float:'+float+';'
	var flag=false;
	if(!user.use)
		{user={color:666666,show:'[禁止使用]'};flag=true;}
	else if((user==null)||(user.show==null&&user.name==null&&user.head==null))
		{user={color:666666,show:'用户已消失'};flag=true;}
	if(inline)
	{
		var adder=document.createElement("span");
		adder.className="user_inline";
		adder.style='width:'+width;
	}
	else
	{
		var adder=document.createElement("div");
		adder.className="user";
		adder.style=float+';width:'+width+';overflow:hidden;';	
	}
	adder.style.background="#"+user.color;
	if(user.show!=null)
		adder.innerHTML=user.show;
	else
	{
		adder.innerHTML=user.name;
		var img=document.createElement("img");	
		img.className=user.head_rotate==1?'rotating':user.head_rotate==0?'rotation':'';
		adder.appendChild(img);
		img.src=user.head;
	}
	if(!flag)
		adder.setAttribute('onclick','get_and_showuser_full('+user.id+',document.body.clientWidth*0.75,document.body.clientHeight*0.75)');	addr.appendChild(adder);
	adder=null;		
}			
function getuser(id,reload,callback,tong)
{
	if(reload==null)
		reload=false;	
	var data=getsync('users');
	if(data!=null)
		var user=data.find(function (a){return a.id==id});
	else
		var user=null;
	if(user!=null&&(!reload))
	{
		if(typeof callback=='function')
			callback();		
		return;
	}
	if(user==null) 
		user={lasttime:"1926-08-17 01:01:01"};
	loadxmldoc('../tools/get_user.php?id='+id+'&lasttime='+user.lasttime,function (data_){
		var buf=JSON.parse(data_);
		var data=getsync('users'); 
		if(buf.id!=-1)
		{
			if(data==null)
			{
				data=new Array();
				data.push(buf);
			}
			else
				if(buf!=null)
				{
					var now=data.indexOF(function(a){return a.id==buf.id});
					if(now==-1)
						data.push(buf);
					else
						data.splice(now,1,buf);
				}
		}
		setsync('users',data);
		if(typeof callback=='function')
			callback();
		},null,tong);
			
}
function get_and_showuser(addr,id,width,float,inline)
{
	getuser(id,false,
	function()
	{
		var data=getsync('users');
		var user=data.find(function (a){return a.id==id});
		loading_off();	
		showuser(addr,user,width,float,inline);
	},false	
	);
}
function showuser_full(user,width,height)
{
	function show_tr_no_input(table,name,value,id)
	{
		var tr=document.createElement("tr");
		table.appendChild(tr);
		var td=document.createElement("td");
		td.width="400";
		var h55=document.createElement("h56");
		td.appendChild(h55);	
		h55.innerHTML=name;
		tr.appendChild(td);	
		td=null;
		var td=document.createElement("td");
		var h55=document.createElement("h56");
		h55.id=id;
		td.appendChild(h55);	
		h55.innerHTML=value;
		tr.appendChild(td);
		return td;
	}
	var title=win.frame('用户查看',width,height,(document.body.clientWidth-width)/2,(document.body.clientHeight-height)/2);	
	var Confirm=document.createElement("button"); title.appendChild(Confirm);    
	Confirm.type="button"; 
	Confirm.innerHTML="关闭"; 
	Confirm.style='float:right;margin:2px 20px;';
	Confirm.onclick=function(event)
	{
		document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
		document.body.removeChild(event.target.parentNode.parentNode); 
	}
	Confirm.setAttribute("class","button_small button1");
	Confirm=null;
	win.msgObj.style.overflowX='hidden';
	win.msgObj.style.overflowY='scroll';
	win.msgObj.align="center";
	var table=document.createElement("table");win.msgObj.appendChild(table);
	table.border=1;table.width="75%";
//ID
	show_tr_no_input(table,'ID',user.id);	
	show_tr_no_input(table,'昵称',user.name);	
//头像	
	var tr=document.createElement("tr");
	table.appendChild(tr);
	var td=document.createElement("td");
	td.width="400";
	var h55=document.createElement("h56");
	td.appendChild(h55);	
	h55.innerHTML='头像';
	tr.appendChild(td);	
	td=null;
	var td=document.createElement("td");
	td.style="overflow: hidden;"; 
	var img=document.createElement("img");
	img.className=user.head_rotate==1?'rotating':user.head_rotate==0?'rotation':'';
	td.appendChild(img);	
	img.src=user.head;
	img.height=80;
	img.width=80;
	tr.appendChild(td);	
	td=null;
	tr=null;	
//绿币
	show_tr_no_input(table,'绿币',user.green_money);	
//注册日期	
	show_tr_no_input(table,'注册日期',user.enroldate);		
	show_tr_no_input(table,'权限组',user.competencename);
	if(user.sex==1)
		show_tr_no_input(table,'性别','男');
	else if(user.sex==0)
		show_tr_no_input(table,'性别','女');
	else if(user.sex==2)
		show_tr_no_input(table,'性别','女装大佬'); 
	else
		show_tr_no_input(table,'性别','???');
	show_tr_no_input(table,'电话',user.tel);
	show_tr_no_input(table,'邮箱',user.mail);
	show_tr_no_input(table,'使用情况',user.use==0?'禁止':'正常');
	if(user.zhushi!=''&&user.zhushi!=null)
	{
		var td=show_tr_no_input(table,'签名','');
		td.innerHTML='';
		markdown(td,0,0,(user.zhushi),false);
	}
	if(user.ips==-1)
		show_tr_no_input(table,'登录信息','该用户的隐私策略不允许展示');
	else
	{
		if(user.ips.length==0)
			show_tr_no_input(table,'登录信息','该用户没有登录');			
		else
		{
			var td=show_tr_no_input(table,'登录信息','该用户的隐私策略不允许展示');
			td.innerHTML='';
			var h55=document.createElement("h56");td.appendChild(h55); 
			for(var i=0,n=user.ips.length;i<n;i++)
			{
				var li=document.createElement("li");h55.appendChild(li);	
				li.innerHTML=user.ips[i];
			}
		}
	}	
	
	
	table=null;
	
}
function get_and_showuser_full(id,width,height)
{
	getuser(id,false,function()
	{
		var data=getsync('users');
		var user=data.find(function (a){return a.id==id});
		loading_off();	
		showuser_full(user,width,height);		
	}
	);		
}function ispc()
{    
	var userAgentInfo = navigator.userAgent;  
	var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");    
	for (var v = 0; v < Agents.length; v++) 
		if (userAgentInfo.indexOf(Agents[v]) > 0)
			return false;
	return true;    
}  function phone_test( phone)
{ 
//    var phone = document.getElementById('phone').value;
    if(!(/^1[34578]\d{9}$/.test(phone)))
        return false; 
	return true;
}function post(URL, PARAMS) 
{
  var temp = document.createElement("form");
  temp.action = URL;
  temp.method = "post";
  temp.style.display = "none";
  for (var x in PARAMS) {
    var opt = document.createElement("textarea");
    opt.name = x;
    opt.value = PARAMS[x];
    // alert(opt.name)
    temp.appendChild(opt);
  }
  document.body.appendChild(temp);
  temp.submit();
  return temp;
}function update_progress(progress_body,progress,word)
{
	progress_body.firstChild.style.width=""+parseFloat(progress)*100+"%";
	progress_body.firstChild.firstChild.innerHTML=word;
}
function add_progress(area,width,progress,word,mouthclick,mouthmove,addclass,type,active)
{
	var progress_body=document.createElement("div");area.appendChild(progress_body);
	progress_body.className="progress tooltip "+addclass;
	progress_body.name="progress_body";
	progress_body.style.width=width;
	var progress_bar=document.createElement("div");progress_body.appendChild(progress_bar);
	progress_bar.name="progress_bar";
	progress_bar.className="progress_bar ";
	if(active)
		progress_bar.className+='active progress_bar_striped ';
	if(type=='error')
		progress_bar.className+='jry_error_color';
	else if(type=='ok')
		progress_bar.className+='jry_ok_color';
	else if(type=='warn')
		progress_bar.className+='jry_warn_color';
	else
		progress_bar.className+='jry_normal_color';
	var text=document.createElement("span");progress_bar.appendChild(text);
	text.oncontextmenu=function(){return false;}; 
	text.onselectstart=function(){return false;};	
	text.name="text";
	var span=document.createElement("span");progress_bar.appendChild(span);
	span.className="tooltiptext"
	span.oncontextmenu=function(){return false;}; 
	span.onselectstart=function(){return false;};
	update_progress(progress_body,progress,word);
	progress_body.onclick=function(e)
	{
		var target=e.target.name=="text"?e.target.parentNode.parentNode:e.target.name=="progress_bar"?e.target.parentNode:e.target;
		var progress=e.layerX/target.scrollWidth;
		if(typeof mouthclick=="function")
			mouthclick(progress);	
	}
	progress_body.onmousemove=function(e)
	{
		var target=e.target.name=="text"?e.target.parentNode.parentNode:e.target.name=="progress_bar"?e.target.parentNode:e.target;
		var progress=e.layerX/target.scrollWidth;
		var span=target.childNodes[0].childNodes[1];
		if(span==null)return;
		var x=Math.max(0,Math.min(e.layerX-(span.scrollWidth/2),target.scrollWidth-(span.scrollWidth)));
		span.style.left=x+"px";		
		if(typeof mouthmove=="function")
			mouthmove(progress);
	}
	return progress_body;
}const jry_keycode_backspace	=8;
const jry_keycode_tab		=9;
const jry_keycode_clear		=12;
const jry_keycode_enter		=13;
const jry_keycode_shift		=16;
const jry_keycode_control	=17;
const jry_keycode_alt		=18;
const jry_keycode_pause		=19;
const jry_keycode_capslock	=20;
const jry_keycode_escape	=27;
const jry_keycode_space		=32;
const jry_keycode_prior		=33;
const jry_keycode_next		=34;
const jry_keycode_end		=35;
const jry_keycode_home		=36;
const jry_keycode_left		=37;
const jry_keycode_up		=38;
const jry_keycode_right		=39;
const jry_keycode_down		=40;
const jry_keycode_select	=41;
const jry_keycode_print		=42;
const jry_keycode_execute	=43;
const jry_keycode_insert	=45;
const jry_keycode_delete	=46;
const jry_keycode_help		=47;
const jry_keycode_0			=48;
const jry_keycode_1			=49;
const jry_keycode_2			=50;
const jry_keycode_3			=51;
const jry_keycode_4			=52;
const jry_keycode_5			=53;
const jry_keycode_6			=54;
const jry_keycode_7			=55;
const jry_keycode_8			=56;
const jry_keycode_9			=57;
const jry_keycode_a			=65;
const jry_keycode_b			=66;
const jry_keycode_c			=67;
const jry_keycode_d			=68;
const jry_keycode_e			=69;
const jry_keycode_f			=70;
const jry_keycode_g			=71;
const jry_keycode_h			=72;
const jry_keycode_i			=73;
const jry_keycode_j			=74;
const jry_keycode_k			=75;
const jry_keycode_l			=76;
const jry_keycode_m			=77;
const jry_keycode_n			=78;
const jry_keycode_o			=79;
const jry_keycode_p			=80;
const jry_keycode_q			=81;
const jry_keycode_r			=82;
const jry_keycode_s			=83;
const jry_keycode_t			=84;
const jry_keycode_u			=85;
const jry_keycode_v			=86;
const jry_keycode_w			=87;
const jry_keycode_x			=88;
const jry_keycode_y			=89;
const jry_keycode_z			=90;
const jry_keycode_win		=91;
const jry_keycode_0_		=96;
const jry_keycode_1_		=97;
const jry_keycode_2_		=98;
const jry_keycode_3_		=99;
const jry_keycode_4_		=100;
const jry_keycode_5_		=101;
const jry_keycode_6_		=102;
const jry_keycode_7_		=103;
const jry_keycode_8_		=104;
const jry_keycode_9_		=105;
const jry_keycode_f1		=112;
const jry_keycode_f2		=113;
const jry_keycode_f3		=114;
const jry_keycode_f4		=115;
const jry_keycode_f5		=116;
const jry_keycode_f6		=117;
const jry_keycode_f7		=118;
const jry_keycode_f8		=119;
const jry_keycode_f9		=120;
const jry_keycode_f10		=121;
const jry_keycode_f11		=122;
const jry_keycode_f12		=123;
var jry_shortcut_tree={'func':function(){},'next':new Array()};;
var jry_shortcut_keycode_buf=new Array();
var jry_shortcut_keycode_buf_count=0;
var jry_shortcut_debug=false;
var jry_shortcut_control_flag=false;
var jry_shortcut_set_flag=false;
var jry_shortcut_on_input_flag=false;
function jry_keycode_debug(keycode)
{
	switch (keycode)
	{
		case jry_keycode_0 :
			console.log("jry_keycode_0");
			break;
		case jry_keycode_1 :
			console.log("jry_keycode_1");
			break;
		case jry_keycode_2 :
			console.log("jry_keycode_2");
			break;
		case jry_keycode_3 :
			console.log("jry_keycode_3");
			break;
		case jry_keycode_4 :
			console.log("jry_keycode_4");
			break;
		case jry_keycode_5 :
			console.log("jry_keycode_5");
			break;
		case jry_keycode_6 :
			console.log("jry_keycode_6");
			break;
		case jry_keycode_7 :
			console.log("jry_keycode_7");
			break;
		case jry_keycode_8 :
			console.log("jry_keycode_8");
			break;
		case jry_keycode_9 :
			console.log("jry_keycode_9");
			break;			
		case jry_keycode_win :
			console.log("jry_keycode_win");
			break;
		case jry_keycode_control :
			console.log("jry_keycode_control");
			break;
		case jry_keycode_win :
			console.log("jry_keycode_win");
			break;
		case jry_keycode_up :
			console.log("jry_keycode_up");
			break;
		case jry_keycode_down :
			console.log("jry_keycode_down");
			break;
		case jry_keycode_left :
			console.log("jry_keycode_left");
			break;
		case jry_keycode_right :
			console.log("jry_keycode_right");
			break;
		case jry_keycode_clear :
			console.log("jry_keycode_clear");
			break;
		case jry_keycode_tab :
			console.log("jry_keycode_tab");
			break;
			
		default:
			console.log(keycode);
			
	}
}
document.onkeydown = function (e) 
{
	if (!e) 
		e = window.event;
	jry_shortcut_on_input_flag|=e.path[0].tagName=="TEXTAREA"||e.path[0].tagName=="INPUT";
	var keycode=(e.keyCode||e.which);
	if(keycode>=jry_keycode_0_&&keycode<=jry_keycode_9_)
		keycode=keycode-jry_keycode_0_+jry_keycode_0;
	if(jry_shortcut_debug)
		jry_keycode_debug(keycode);
	jry_shortcut_keycode_buf[jry_shortcut_keycode_buf_count++]=keycode;
	if(!jry_shortcut_set_flag)
	{
		jry_shortcut_set_flag=true;
		setTimeout(function(){
			var now=jry_shortcut_tree;
			var n=jry_shortcut_keycode_buf_count;
			jry_shortcut_set_flag=false;
			jry_shortcut_keycode_buf_count=0;
			jry_shortcut_control_flag=false;
			if(jry_shortcut_on_input_flag&&jry_shortcut_keycode_buf[0]!=jry_keycode_control&&jry_shortcut_keycode_buf[0]!=jry_keycode_alt&&jry_shortcut_keycode_buf[0]!=jry_keycode_win)
			{
				jry_shortcut_on_input_flag=false;
				return;
			}
			for(var i=0;i<n;i++)
			{
				if(now==null)
					return;
				now=now.next[jry_shortcut_keycode_buf[i]];
			}
			if(now==null||now.func==null)
				return ;
			if(typeof now.func=="function")
				now.func(e);
		},500);
	}
	jry_shortcut_control_flag=(keycode==jry_keycode_control);
	return !jry_shortcut_control_flag;
}



function jry_setshort_cut(code,func)
{
	var now=jry_shortcut_tree.next;
	for(var i=0,n=code.length;i<n;i++)
	{
		if(now[code[i]]==null)
			now[code[i]]={'func':function(){},'next':new Array()};
		if(i!=(n-1))
			now=now[code[i]].next;
	}
	now[code[code.length-1]].func=func;
}function connect_special_delate() 
{
	var buf=document.getElementsByTagName('input');
	for(var i=0;i<buf.length;i++)
		if(buf[i].type!='password')
			connect_special_delate_one(buf[i]);
}
function connect_special_delate_one(input)
{
	var func=function(event){event.target.value=event.target.value.replace(/[^\a-\z\A-\Z0-9\u4E00-\u9FA5\@\，\.\,\。\!\！\-\_\+\=\—\ \（\(\）\)\/\\:]/g,'')};	
	var onpaste=input.onpaste;  
  	if (typeof input.onpaste!='function')
    	input.onpaste=func;
	else
    	input.onpast=function(data){if(onpaste)onpaste(data);func(data);};
	var oncontextmenu=input.onpaste;  
  	if (typeof input.oncontextmenu!='function')
    	input.oncontextmenu=func;
	else
    	input.oncontextmenu=function(data){if(oncontextmenu)oncontextmenu(data);func(data);};
	var onkeyup=input.onkeyup;  
	if (typeof input.onkeyup!='function')
    	input.onkeyup=func;
	else
    	input.onkeyup=function(data){if(onkeyup)onkeyup(data);func(data);};
}function setsync(name,data,longtime)
{
	if(longtime==null)
		longtime=true;
	if(longtime)
		localStorage.setItem(name,JSON.stringify({lasttime:get_server_time(),data:data}));
	else 
		sessionStorage.setItem(name,JSON.stringify({lasttime:get_server_time(),data:data}));
}
function getsync(name)
{
	var buf=JSON.parse(localStorage.getItem(name));
	if(buf==null)
		buf=JSON.parse(sessionStorage.getItem(name));
	if(buf==null)
		return null;
	if(buf.data==null||(typeof buf.data=="object"&&buf.data.length==0))
		return null;
	return buf.data;
}
function getsync_lasttime(name)
{
	var buf=JSON.parse(localStorage.getItem(name));
	if(buf==null)
		buf=JSON.parse(sessionStorage.getItem(name));
	if(buf==null)
		return '1926-08-17 01:01:01';
	if(buf.data==null||(typeof buf.data=="object"&&buf.data.length==0))
		return '1926-08-17 01:01:01';
	return buf.lasttime;
}
function setsync_lasttime(name,time,longtime)
{
	if(longtime==null)
		longtime=true;
	var data=getsync(name);
	if(longtime)
		localStorage.setItem(name,JSON.stringify({lasttime:time,data:data}));
	else
		sessionStorage.setItem(name,JSON.stringify({lasttime:time,data:data}));	
}
function deletesync(name)
{
	localStorage.removeItem(name);	
	sessionStorage.removeItem(name);
}



function sync_data_with_server(syncname,dataurl,array,cmp,after,sort_cmp)
{
	loadxmldoc(dataurl,function(data)
	{
		var buf=JSON.parse(data);
		var data=getsync(syncname);
		if(buf!=null)
			if(buf.login==false)
			{
				win.alert("没有登录","因为"+buf.reasion,"window.location.href='"+returnaddr+"'");
				return ;	
			}	
		if(data==null)
			data=buf;
		else 
			if(buf!=null)
				for(var i=0,n=buf.length;i<n;i++)
				{
					var now=data.indexOF(cmp,buf[i]);
					if(now==-1)
						data.push(buf[i]);
					else
						data.splice(now,1,buf[i]);
				}
		if(typeof sort_cmp=='function')
			data.sort(sort_cmp);
		setsync(syncname,data);
		loading_off();	
		after(data);
	},array);
}
function get_time() 
{
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            + " " + date.getHours() + seperator2 + date.getMinutes()
            + seperator2 + date.getSeconds();
    return currentdate;
}
var __zhongcha=null;
function get_server_time()
{
	if(__zhongcha==null)
	{
		if(window.XMLHttpRequest)
			var xhr = new window.XMLHttpRequest();
		else
			var xhr = new ActiveObject("Microsoft")
		xhr.open("GET","/null.html",false)//false不可变
		xhr.send(null);
		var date = xhr.getResponseHeader("Date");
		date = new Date(date.replace(/\-/g, "/"));
		var date1 = new Date();
		__zhongcha=(date.getMilliseconds() - date1.getMilliseconds());//服务器减本机
	}
	else
	{
		date =new Date();
		date.setMilliseconds(date.getMilliseconds()+__zhongcha);	
	}
	var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            + " " + date.getHours() + seperator2 + date.getMinutes()
            + seperator2 + date.getSeconds();
    return currentdate;
}
function mathtime(intime) 
{
	var date1 = new Date(get_server_time().replace(/\-/g, "/"));
	var date2 = new Date(intime.replace(/\-/g, "/"));
	var ms = (date2.getTime() - date1.getTime());
	var day=parseInt(ms/(24*60*60*1000));
	var hour=parseInt(ms/(60*60*1000))-day*24;
	var minute=parseInt(ms/(60*1000))-hour*60-day*24*60;
	var s=parseInt(ms/(1000))-minute*60-hour*60*60-day*24*60*60;
	return ""+day+"-"+hour+"-"+minute+"-"+s;
}
function showtime(intime,addre) 
{
	var date=mathtime(intime);
	var _date=date.split("-");
	var day=_date[0];
	var hour=_date[1];
	var minute=_date[2];
	var s=_date[3];
	document.getElementById(addre).innerHTML=day+"天"+hour+"时"+minute+"分"+s+"秒";
	timerid = setTimeout("showtime('"+intime+"','"+addre+"')",1000);
	timerRunning = true;
}
function comparetime(d1,d2)
{
	return ((new Date(d1.replace(/-/g,"\/")))-(new Date(d2.replace(/-/g,"\/"))));
}
function addEvent(el,name,fn)
{//绑定事件
	if(el.addEventListener) 
		return el.addEventListener(name,fn,false);
	return el.attachEvent('on'+name,fn);
}
function nextnode(node)
{//寻找下一个兄弟并剔除空的文本节点
	if(!node)return ;
	if(node.nodeType == 1)
		return node;
	if(node.nextSibling)
		return nextnode(node.nextSibling);
} 
function prevnode(node)
{//寻找上一个兄弟并剔除空的文本节点
	if(!node)return ;
	if(node.nodeType == 1)
		return node;
	if(node.previousSibling)
		return prevnode(node.previousSibling);
} 
function parcheck(self,checked)
{//递归寻找父亲元素，并找到input元素进行操作
	var par =  prevnode(self.parentNode.parentNode.parentNode.previousSibling);
	if(par&&par.getElementsByTagName('input')[0])
	{
		par.getElementsByTagName('input')[0].checked = checked;
		parcheck(par.getElementsByTagName('input')[0],sibcheck(par.getElementsByTagName('input')[0]));
	}           
}
function sibcheck(self)
{//判断兄弟节点是否已经全部选中
	var sbi = self.parentNode.parentNode.parentNode.childNodes,n=0;
	for(var i=0;i<sbi.length;i++)
	{
		if(sbi[i].nodeType != 1)//由于孩子结点中包括空的文本节点，所以这里累计长度的时候也要算上去
			n++;
		else 
			if(sbi[i].getElementsByTagName('input')[0]!=null) 
				if(sbi[i].getElementsByTagName('input')[0].checked)
					n++;
	}
	return n==sbi.length?true:false;
}
function tree_init(div)
{
	var labels = div.getElementsByTagName('label');
	addEvent(div,'click',function(e)
	{//绑定input点击事件，使用root根元素代理
		e = e||window.event;
		var target = e.target||e.srcElement;
		var tp = nextnode(target.parentNode.nextSibling);
		switch(target.nodeName){
			case 'SPAN'://点击图标只展开或者收缩
				var ap = nextnode(nextnode(target.nextSibling).nextSibling);
				if(ap.style.display != 'block' )
				{
					ap.style.display = 'block';
					target.className = 'fa fa-toggle-up tree_button'
				}else{
					ap.style.display = 'none';
					target.className = 'fa fa-toggle-down tree_button '
				}
				break;
			case 'INPUT'://点击checkbox，父亲元素选中，则孩子节点中的checkbox也同时选中，孩子结点取消父元素随之取消
				if(target.checked)
				{
					if(tp)
					{
						var checkbox = tp.getElementsByTagName('input');
						for(var i=0;i<checkbox.length;i++)
							checkbox[i].checked = true;
					} 
				}
				else
				{
					if(tp)
					{
						var checkbox = tp.getElementsByTagName('input');
						for(var i=0;i<checkbox.length;i++)
							checkbox[i].checked = false;
					}
				}
				parcheck(target,sibcheck(target));//当孩子结点取消选中的时候调用该方法递归其父节点的checkbox逐一取消选中
				break;
		}
	});
	for(var i=0;i<labels.length;i++)
	{
		var span = document.createElement('span');
		span.style.cssText ='display:inline-block;vertical-align:middle;cursor:pointer;';
		span.innerHTML = ' '
		span.className = 'fa fa-toggle-down tree_button ';
		if(nextnode(labels[i].nextSibling)&&nextnode(labels[i].nextSibling).nodeName == 'UL')
			labels[i].parentNode.insertBefore(span,labels[i]);
		else
			labels[i].className = 'rem'
	}	
	
}
function getcheck(ul)
{
	var all=ul.getElementsByTagName('input');
	var array=new Array()
	for(var i=0;i<all.length;i++)
	{
		if(all[i].checked)
			array.push(all[i].value);
	}
	return array;
}Array.prototype.unique = function()
{
	var res = [];
	var json = {};
	for(var i = 0; i < this.length; i++)
	{
		if(!json[this[i]])
		{
			res.push(this[i]);
			json[this[i]] = 1;
		}
	}
	return res;
};function  win_function() 
{
	this.frame=function(msgtitle,width,height,x,y)
	{
		this.bgObj=document.createElement("div");
		this.bgObj.setAttribute("class","bgDiv"); 
		document.body.appendChild(this.bgObj); 
		this.msgObj=document.createElement("div") ;
		this.msgObj.setAttribute("class","msgDiv"); 
		this.msgObj.style.top = y; 
		this.msgObj.style.left =x; 
		this.msgObj.style.width=width;
		this.msgObj.style.height=height;
		document.body.appendChild(this.msgObj); 
		var title=document.createElement("div"); 
		title.setAttribute("class","msgTitle"); 
		title.style="overflow:hidden;";
		title.align="center";
		title.style.width=width;
		if(msgtitle) 
			title.innerHTML=msgtitle; 
		else
			title.innerHTML="系统提示"; 	
		this.msgObj.appendChild(title); 		
		bgObj=null;
		return title;
	}
	this.close=function()
	{
		document.body.removeChild(this.bgObj); 	
		document.body.removeChild(this.msgObj); 		
	}
	this.prompt=function(msgtitle,func)
	{
		this.frame(msgtitle,400,200,(document.body.clientWidth-400)/2,(document.body.clientHeight-400)/2);
		var txt=document.createElement("input");this.msgObj.appendChild(txt);
		txt.className="msgTxt h56";
		txt=null;
		var buttom=document.createElement("div");this.msgObj.appendChild(buttom); 
		buttom.className="msgButton"; 
		buttom.setAttribute("align","center"); 
		buttom.style="width:100%;buttom:0px;";
		var Confirm=document.createElement("input");buttom.appendChild(Confirm);  
		Confirm.className="button_small button1";
		Confirm.type='button'; 
		Confirm.value="确认"; 
		Confirm.style.bottom=0;
		Confirm.onclick=function(event)
		{
			var value=event.target.parentNode.parentNode.getElementsByTagName('input')[0].value;
			if(value!='')
				func(value);
			else
				right.alert('未执行操作',2000,'auto');
			document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
			document.body.removeChild(event.target.parentNode.parentNode); 
		}
	}
	this.check=function(msgtitle,funcy,funcn,wordy,wordn)
	{
		if(wordy==null)wordy='确定';
		if(wordn==null)wordn='取消';
		this.frame(msgtitle,400,200,(document.body.clientWidth-400)/2,(document.body.clientHeight-400)/2);
		var buttom=document.createElement("div");
		buttom.setAttribute("class","msgButton"); 
		buttom.setAttribute("align","center"); 
		buttom.setAttribute("style","width:100%;buttom:0px;"); 
		this.msgObj.appendChild(buttom);    
		var Confirm=document.createElement("input"); 
		Confirm.setAttribute("type","button"); 
		Confirm.setAttribute("value",wordy); 
		Confirm.style.bottom=0;
		Confirm.onclick=function(event)
		{
			document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
			document.body.removeChild(event.target.parentNode.parentNode); 
			funcy();
		}
		Confirm.setAttribute("class","button_small button1");
		buttom.appendChild(Confirm);    
		Confirm=null;
		var Confirm=document.createElement("input"); 
		Confirm.setAttribute("type","button"); 
		Confirm.setAttribute("value",wordn); 
		Confirm.style.bottom=0;
		Confirm.onclick=function(event)
		{
			document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
			document.body.removeChild(event.target.parentNode.parentNode); 
			funcn();
		}
		Confirm.setAttribute("class","button_small button3");
		buttom.appendChild(Confirm);    
		Confirm=null;
		
		msgbutton=null;   		
	}
	this.alert=function(msgtitle,msgbody,func)
	{
		this.frame(msgtitle,400,200,(document.body.clientWidth-400)/2,(document.body.clientHeight-400)/2);
		var txt=document.createElement("div"); 
		txt.setAttribute("class","msgTxt");
		txt.innerHTML = msgbody; 
		this.msgObj.appendChild(txt);
		txt=null;
		var buttom=document.createElement("div");
		buttom.setAttribute("class","msgButton"); 
		buttom.setAttribute("align","center"); 
		buttom.setAttribute("style","width:100%;buttom:0px;"); 
		this.msgObj.appendChild(buttom);    
		var Confirm=document.createElement("input"); 
		Confirm.setAttribute("type","button"); 
		Confirm.setAttribute("value","确认"); 
		Confirm.style.bottom=0;
		if(typeof func==='function')
		{
			Confirm.onclick=function(event)
			{
				document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
				document.body.removeChild(event.target.parentNode.parentNode); 
				func();
			}
		}
		else
		{
			Confirm.onclick=function(event)
			{
				document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 	
				document.body.removeChild(event.target.parentNode.parentNode); 
				eval(func);
			}			
		}
		Confirm.setAttribute("class","button_small button1");
		buttom.appendChild(Confirm);    
		Confirm=null;
		msgbutton=null;   
	}
	this.open=function(msgtitle,width,height,url,func)
	{
		var title=this.frame(msgtitle,width,height,(document.body.clientWidth-width)/2,(document.body.clientHeight-height)/2);
		var txt=document.createElement("iframe"); 
		txt.setAttribute("src",url);
		txt.setAttribute("seamless",'seamless');
		txt.setAttribute("frameborder",'0');
		txt.setAttribute("width",'100%');
		txt.style.width=height-title.getBoundingClientRect().top;
		this.msgObj.appendChild(txt);
		txt=null; 
		var Confirm=document.createElement("button"); 
		Confirm.type="button"; 
		Confirm.innerHTML="关闭"; 
		Confirm.style='float:right;';
		if(typeof func==='function')
		{
			Confirm.onclick=function(event)
			{
				document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
				document.body.removeChild(event.target.parentNode.parentNode); 
				func();
			}
		}
		else
		{
			Confirm.onclick=function(event)
			{
				document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 	
				document.body.removeChild(event.target.parentNode.parentNode); 
				eval(func);
			}			
		}
		Confirm.setAttribute("class","button_small button1");
		title.appendChild(Confirm);    
		Confirm=null;
		msgbutton=null;   
	}
	this.openvideo=function(msgtitle,width,height,url,func,show_close_button)
	{
		if(show_close_button==null ||typeof show_close_button!="function")
			show_close_button=function(){return true;};
		var title=this.frame(msgtitle,width,height,(document.body.clientWidth-width)/2,(document.body.clientHeight-height)/2);
		var div=document.createElement("div"); this.msgObj.appendChild(div);
		div.style="width:100%;margin:0;padding:0;overflow-y:scroll;overflow-x:hidden;";
		div.style.height=height-title.clientHeight;
		div.align='center';		
		var video=document.createElement("video");div.appendChild(video);
		video.style='height:100%;width:100%;';
		video.src=url;
		video.ontimeupdate=function()
		{
			if(show_close_button(video))
			{
				if(title.getElementsByTagName("button").length!=0)
					return;
				var Confirm=document.createElement("button");title.appendChild(Confirm);
				Confirm.type="button"; 
				Confirm.innerHTML="关闭"; 
				Confirm.style='float:right;margin-right:10px;';
				if(typeof func==='function')
				{
					Confirm.onclick=function(event)
					{
						document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
						document.body.removeChild(event.target.parentNode.parentNode); 
						func(video);
						if((!qq_music_player_paused)&&(qq_music_player.__.audio.paused))
							qq_music_player.play(getsync("playing").id);
					}
				}
				else
				{
					Confirm.onclick=function(event)
					{
						document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 	
						document.body.removeChild(event.target.parentNode.parentNode); 
						eval(func);
						if((!qq_music_player_paused)&&(qq_music_player.__.audio.paused))
							qq_music_player.play(getsync("playing").id);
					}			
				}
				Confirm.className="button_small button3";
			}
		}
		var video_body=beautiful_video(video);
		video_body.style.height=height-title.clientHeight;
	}
	this.openpicture=function(msgtitle,width,height,url)
	{
		var title=this.frame(msgtitle,width,height,(document.body.clientWidth-width)/2,(document.body.clientHeight-height)/2);
		var div=document.createElement("div"); this.msgObj.appendChild(div);
		div.style="width:100%;margin:0;padding:0;overflow-y:scroll;overflow-x:hidden;";
		div.style.height=height-title.getBoundingClientRect().top;
		div.align='center';
		var txt=document.createElement("img");
		txt.style.maxWidth='100%';
		if(url.indexOf("?")==-1)
			txt.src=url+'?size='+parseInt(width);
		else
			txt.src=url+'&size='+parseInt(width);
		div.appendChild(txt);
		txt=null; 
		var Confirm=document.createElement("button"); 
		Confirm.type="button"; 
		Confirm.innerHTML="关闭"; 
		Confirm.style='float:right;margin-right:10px;';
		if(typeof func==='function')
		{
			Confirm.onclick=function(event)
			{
				document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 
				document.body.removeChild(event.target.parentNode.parentNode); 
				func();
			}
		}
		else
		{
			Confirm.onclick=function(event)
			{
				document.body.removeChild(event.target.parentNode.parentNode.previousSibling); 	
				document.body.removeChild(event.target.parentNode.parentNode); 
				eval(func);
			}			
		}
		Confirm.setAttribute("class","button_small button3");
		title.appendChild(Confirm);
		Confirm=null;
		msgbutton=null;   
	}	
}
var win = new  win_function;
function  right_function()
{
	addload(()=>{
		this.bgObj=document.createElement("div");document.body.appendChild(this.bgObj); 
		this.bgObj.className='window_right';
	});
	this.alert=function(message,time,width,type)
	{
		var one=document.createElement("div");this.bgObj.appendChild(one); 
		if(type=='error')
			one.className='jry_error_color h55 window_right_div';	
		else if(type=='ok')
			one.className='jry_ok_color h55 window_right_div';
		else if(type=='warn')
			one.className='jry_warn_color h55 window_right_div';
		else
			one.className='jry_normal_color h55 window_right_div';
		one.innerHTML=message;
		one.style.width=width;
		one.onclick=function(){one.parentNode.removeChild(one)};
		setTimeout(function(){one.parentNode.removeChild(one)},time);
	}
}
var right = new  right_function;var word_special_fact_switch=true;
function word_special_fact(event)
{
	if(!word_special_fact_switch)return ;
	if(event.touches)
		event = event.touches[0];
	else 
		event = event;
	var word=document.createElement("span");document.body.appendChild(word);
	var scrollTop=document.body.scrollTop==0?document.documentElement.scrollTop:document.body.scrollTop;
	var scrollLeft=document.body.scrollLeft==0?document.documentElement.scrollLeft:document.body.scrollLeft;
	word.innerHTML=__tanmu[parseInt(Math.random()*__tanmu.length%__tanmu.length)];
	word.style="position:absolute;"; 
	word.style.top=event.clientY-35+scrollTop;word.style.left=Math.min(event.clientX+scrollLeft,document.body.clientWidth+scrollLeft-word.offsetWidth-35);
	word.style.fontSize=30;
	word.className='span_word_special_fact';
	function chenge()
	{
		var scrollTop=document.body.scrollTop==0?document.documentElement.scrollTop:document.body.scrollTop;		
		if(parseInt(word.style.top)>=scrollTop)
		{
			setTimeout(chenge,15);
			word.style.top=parseInt(word.style.top)-6;
			if(parseFloat(word.style.fontSize)>=16)
				word.style.fontSize=(parseFloat(word.style.fontSize)-0.4)+'px';
		}
		else
			document.body.removeChild(word);
	}
	setTimeout(chenge,15);
}
var follow_switch=true;
var follow = function (div,config)
{
	var config=config;
	this.div=div;
	config.size=config.size*5+15;
	var objs=new Array(),N;
	var m={x:0,y:0};
	var center={x:100,y:100};
	var clientWidth=document.body.clientWidth-4;
	var clientHeight=document.body.clientHeight-4;
	N=0;
	this.init=function()
	{
		setTimeout(function(){if(!follow_switch)return;clientWidth=document.body.clientWidth-4;clientHeight=document.body.clientHeight-4;},1000);
		addresize(function(){if(!follow_switch)return;clientWidth=document.body.clientWidth-4;clientHeight=document.body.clientHeight-4;});
		addmousemove(function(event){if(!follow_switch)return;if(event.touches)event = event.touches[0];else event = event;m.x=event.clientX;m.y=event.clientY;});
		addonclick(function(){if(!follow_switch)return;for(var i=0;i<N;i++){objs[i].obj.className='span_mouth_spacial_fact_onclick'}setTimeout(function(){for(var i=0;i<N;i++){objs[i].obj.className='span_mouth_spacial_fact';}},100);});
		this.reinit();
	}
	this.close=function()
	{
		follow_switch=false;
		for(var i=0;i<N;i++)
			if(objs[i]!=null&&objs[i].obj!=null&&objs[i].obj.parentNode!=null)
				objs[i].obj.parentNode.removeChild(objs[i].obj);
		N=0;
	}
	this.reinit=function()
	{
		follow_switch=true;
		setTimeout(()=>{this.mouth_move()},10);
		for(var i=1;i<=360;i+=12)
			for(var j=15;j<config.size;j+=5) 
			{
				objs[N]={'obj':document.createElement("span"),'j':j,'x_pian':Math.sin(i*Math.PI/180),'y_pian':Math.cos(i*Math.PI/180),'x':0,'y':0};
				this.div.appendChild(objs[N].obj);
				objs[N].obj.className='span_mouth_spacial_fact';
				objs[N].obj.style.left=(objs[N].x=center.x+objs[N].x_pian)+'px';
				objs[N].obj.style.top=(objs[N].y=center.y+objs[N].y_pian)+'px';
				objs[N].obj.style.zIndex=config.size+10-j;
				objs[N].x_pian=objs[N].j*objs[N].x_pian;
				objs[N].y_pian=objs[N].j*objs[N].y_pian;
				objs[N].pian=(objs[N].j/config.size)*(config.dou);
				N++;
			}		
	}
	this.mouth_move=function()
	{
		var scrollTop=document.body.scrollTop==0?document.documentElement.scrollTop:document.body.scrollTop;
		var scrollLeft=document.body.scrollLeft==0?document.documentElement.scrollLeft:document.body.scrollLeft;
		var x=m.x+scrollLeft,y=m.y+scrollTop;
		center.x+=(x-center.x)/(config.speed);
		center.y+=(y-center.y)/(config.speed);
		var min_top=scrollTop,max_top=scrollTop+clientHeight;
		var min_left=scrollLeft,max_left=scrollLeft+clientWidth;
		for(var i=0,n=objs.length;i<n;i++)
		{
			objs[i].obj.style.left=Math.max(min_left,Math.min(max_left,(objs[i].x=Math.round(center.x+objs[i].x_pian+objs[i].pian*(center.x-x)))))+'px';
			objs[i].obj.style.top=Math.max(min_top,Math.min(max_top,(objs[i].y=Math.round(center.y+objs[i].y_pian+objs[i].pian*(center.y-y)))))+'px';
		}
		if(follow_switch)
			setTimeout(()=>{this.mouth_move()},10);
	}
	this.init();
};
